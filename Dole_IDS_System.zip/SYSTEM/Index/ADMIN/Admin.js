// --- SESSION & AUTHENTICATION ---
class SessionManager {
    constructor() {
        this.loadSession();
    }
    
    loadSession() {
        const session = localStorage.getItem('userSession');
        this.currentUser = session ? JSON.parse(session) : null;
        this.token = localStorage.getItem('authToken');
    }
    
    saveSession(user, token) {
        localStorage.setItem('userSession', JSON.stringify(user));
        localStorage.setItem('authToken', token);
        this.currentUser = user;
        this.token = token;
    }
    
    clearSession() {
        localStorage.removeItem('userSession');
        localStorage.removeItem('authToken');
        this.currentUser = null;
        this.token = null;
    }
    
    isAuthenticated() {
        return this.token && this.currentUser;
    }
}

const session = new SessionManager();

const appRoot = window.location.pathname.split('/').slice(0, 2).join('/') || '';
const loginApiBase = `${window.location.origin}${appRoot}/Login`;
const loginPageUrl = `${window.location.origin}${appRoot}/Login/login.php`;
const logoutPageUrl = `${window.location.origin}${appRoot}/Login/logout.php`;
const inventoryApiBase = `${window.location.origin}${appRoot}/Inventory/inventory.php`;
const requestsApiBase = `${window.location.origin}${appRoot}/Requests/requests.php`;

// --- BACKEND INTEGRATION GUIDE ---
// 
// The frontend is now structured to easily integrate with a backend API.
// Here's how to replace hardcoded data with API calls:
//
// 1. AUTHENTICATION:
//    - On login page: Call API endpoint, store token and user info using session.saveSession(user, token)
//    - session.isAuthenticated() checks if user is logged in
//    - session.token contains the auth token for API requests
//
// 2. DATA FETCHING:
//    - Replace individual data arrays with async functions
//    - Example: async function fetchInventory() { 
//        const response = await fetch('api/inventory', { headers: { 'Authorization': `Bearer ${session.token}` }});
//        inventoryData = await response.json();
//        renderInventory('all');
//      }
//    - Call on page load or data refresh
//
// 3. API ENDPOINTS NEEDED:
//    - POST /api/login - Authenticate user
//    - GET /api/inventory - Fetch inventory items
//    - GET /api/requests - Fetch request records
//    - GET /api/users - Fetch user list
//    - GET /api/activities - Fetch recent activities
//    - POST /api/requests/:id/approve - Approve request
//    - POST /api/requests/:id/decline - Decline request
//    - POST /api/items - Add new inventory item
//    - POST /api/users - Add new user
//
// 4. ERROR HANDLING:
//    - Add try-catch blocks around fetch calls
//    - Handle 401 errors by calling logout() and redirecting to login
//    - Display user-friendly error messages
//
// 5. INITIALIZATION:
//    - Check session.isAuthenticated() before loading admin page
//    - If not authenticated, redirect to login
//    - Load all required data before showing page

// --- CENTRAL DATA ---
let inventoryData = [];

// Recent Requests Data (will be populated from backend)
let recentRequestsData = [];

// Requests Data (full list, will be populated from backend)
let requestsData = [];

// Recent Activities Data
let activitiesData = [
    { type: "request", name: "Cavite", action: "requested 5 reams of Bond Paper (Short)", time: "1m" },
    { type: "approved", name: "Flavio D.", action: "approved a request of Ballpoint Pens", time: "5m" },
    { type: "declined", name: "Flavio D.", action: "declined a request of A4 Notebooks", time: "30m" }
];

// Notifications Data
let notificationsData = [
    // Today
    { type: "info", category: "request", title: "New Request!", message: "CAVITE requested 5 box Ballpoint Pen (Black).", time: "3m ago", isToday: true },
    { type: "warning", category: "inventory", title: "Low Stock Alert!", message: "Ballpoint Pen (Black) is running low (6 boxes).", time: "10m ago", isToday: true },
    { type: "success", category: "request", title: "Request Approved", message: "BATANGAS request for Paper Clips has been approved by Fl...", time: "13m ago", isToday: true },
    { type: "error", category: "inventory", title: "Out of Stock", message: "Correction Tape is now out of stock.", time: "20m ago", isToday: true },
    { type: "error", category: "request", title: "Request Declined", message: "BATANGAS request for A4 Notebook was declined by Kurt...", time: "1 hr ago", isToday: true },
    
    // Older
    { type: "success", category: "inventory", title: "Stock Updated", message: "Bond Paper (Short) stock updated to 100 units", time: "Yesterday", isToday: false },
    { type: "error", category: "request", title: "Request Declined", message: "CAVITE request for Calculator was declined by Flavio Deza I...", time: "Yesterday", isToday: false },
    { type: "system", category: "system", title: "System Update Available", message: "New system update v2.1 is available", time: "2 day ago", isToday: false },
    { type: "warning", category: "inventory", title: "Low Stock Alert!", message: "Folder (Expandable) stock is low", time: "3 day ago", isToday: false }
];

// Users Data
let usersData = [
    { name: "Flavio Deza", email: "fdeza@gmail.com", role: "Admin", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza II", email: "fdeaza2@gmail.com", role: "Admin", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza III", email: "fdeaza3@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza IV", email: "fdeaza4@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza V", email: "fdeaza5@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VI", email: "fdeaza6@gmail.com", role: "Requester", province: "BATANGAS", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VII", email: "fdeaza7@gmail.com", role: "Requester", province: "CAVITE", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VIII", email: "fdeaza8@gmail.com", role: "Requester", province: "QUEZON", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza IX", email: "fdeaza9@gmail.com", role: "Requester", province: "RIZAL", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" }
];
const navItems = document.querySelectorAll(".nav li, .nav-bottom li");
const pages = document.querySelectorAll(".page");
const centralNavItems = document.querySelectorAll(".central-nav-item");

navItems.forEach(item => {
    item.onclick = () => {
        if(item.dataset.page === 'logout') {
            logout();
        } else {
            showPage(item.dataset.page);
        }
    };
});

centralNavItems.forEach(item => {
    item.onclick = () => {
        if (item.dataset.page === 'logout') {
            logout();
        } else {
            showPage(item.dataset.page);
        }
    };
});

function showPage(pageId) {
    pages.forEach(p => p.classList.remove("active"));
    navItems.forEach(n => n.classList.remove("active"));
    
    document.getElementById(pageId).classList.add("active");
    document.querySelector(`.nav li[data-page="${pageId}"], .nav-bottom li[data-page="${pageId}"]`).classList.add("active");
    
    const titleMap = {
        'dashboard': 'Dashboard',
        'usermanagement': 'User Management',
        'inventory': 'Inventory',
        'approvals': 'Requests Management',
        'reports': 'Reports',
        'system': 'System',
        'settings': 'Settings'
    };
    
    document.getElementById("page-title").textContent = titleMap[pageId] || pageId.charAt(0).toUpperCase() + pageId.slice(1);
    
    if(pageId === 'dashboard') {
        initDashboard();
    }
    if(pageId === 'inventory') renderInventory('all');
    if(pageId === 'approvals') renderRequests('all');
    if(pageId === 'usermanagement') renderUsers();
}

// --- LOGOUT FUNCTIONALITY ---
function logout() {
    // Clear session data
    session.clearSession();
    
    // Clear all data arrays
    inventoryData = [];
    recentRequestsData = [];
    activitiesData = [];
    notificationsData = [];
    approvalsData = [];
    usersData = [];
    requestsData = [];
    
    // Redirect to login page through server logout
    window.location.href = logoutPageUrl;
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toastMessage');
    if (!toast) return;

    toast.textContent = message;
    toast.className = `toast-message toast-${type} show`;
    clearTimeout(toast.hideTimer);
    toast.hideTimer = setTimeout(() => {
        toast.className = `toast-message toast-${type}`;
    }, 3200);
}

// --- DASHBOARD LOGIC ---
function getStatus(stock, min) {
    if (stock <= 0) return "out";
    if (stock <= min) return "low";
    return "in";
}

function initDashboard() {
    renderDashboardStats();
    renderRecentRequests();
    renderRecentActivities();
    renderPopularItems();
    renderActivitySummary();
}

function renderDashboardStats() {
    let totalCount = inventoryData.length;
    let lowCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').length;
    let outCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').length;
    
    document.getElementById("totalInventoryCount").textContent = totalCount.toString().padStart(2, '0');
    document.getElementById("lowStockCount").textContent = lowCount.toString().padStart(2, '0');
    document.getElementById("outStockCount").textContent = outCount.toString().padStart(2, '0');
}

function renderRecentRequests() {
    const table = document.getElementById("recentRequestsTable");
    table.innerHTML = "";
    
    recentRequestsData.forEach(req => {
        let statusClass = req.status.toLowerCase();
        const statusColor = statusClass === 'pending' ? 'yellow' : statusClass === 'approved' ? 'green' : 'red';
        
        // Format date to MM-DD-YYYY
        const requestDate = new Date(req.request_date);
        const formattedDate = (requestDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                             requestDate.getDate().toString().padStart(2, '0') + '-' +
                             requestDate.getFullYear();
        
        table.innerHTML += `
            <tr>
                <td>${req.item_name}</td>
                <td>${req.quantity} pcs</td>
                <td>${formattedDate}</td>
                <td><span class="status ${statusColor}">${req.status}</span></td>
                <td>${req.requestor}</td>
            </tr>
        `;
    });
}

function renderRecentActivities() {
    const list = document.getElementById("recentActivitiesList");
    list.innerHTML = "";
    
    activitiesData.forEach(activity => {
        const iconClass = `activity-icon ${activity.type}`;
        const iconMap = {
            request: "📍",
            approved: "✓",
            declined: "✕"
        };
        
        list.innerHTML += `
            <div class="activity-item">
                <div class="${iconClass}">${iconMap[activity.type]}</div>
                <div class="activity-text">
                    <span class="activity-name">${activity.name}</span>
                    <div class="activity-description">${activity.action}</div>
                </div>
                <span class="activity-time">${activity.time}</span>
            </div>
        `;
    });
}

function renderPopularItems() {
    const list = document.getElementById("popularItemsList");
    list.innerHTML = "";
    
    // Get items sorted by most requested (using recentRequestsData as popularity metric)
    const requestedItems = recentRequestsData.map(req => req.item);
    const popularItemsSet = new Set(requestedItems);
    
    const itemsWithStatus = inventoryData
        .filter(item => popularItemsSet.has(item.item_name))
        .map(item => ({
            ...item,
            status: getStatus(item.stock, item.min_stock)
        }))
        .slice(0, 5);
    
    // If not enough items from requests, add some from inventory
    if (itemsWithStatus.length < 5) {
        const additionalItems = inventoryData
            .filter(item => !popularItemsSet.has(item.item_name))
            .slice(0, 5 - itemsWithStatus.length)
            .map(item => ({
                ...item,
                status: getStatus(item.stock, item.min_stock)
            }));
        itemsWithStatus.push(...additionalItems);
    }
    
    itemsWithStatus.forEach(item => {
        const indicatorClass = item.status === 'in' ? 'indicator-green' : 
                              item.status === 'low' ? 'indicator-yellow' : 'indicator-red';
        const id = `ITM${String(item.id).padStart(4, '0')}`;
        
        list.innerHTML += `
            <li>
                <div class="popular-item-left">
                    <div style="min-width:0;">
                        <div class="item-name">${item.item_name}</div>
                        <div class="item-id">${id}</div>
                    </div>
                </div>
                <div class="item-stock-indicator ${indicatorClass}"></div>
            </li>
        `;
    });
}

function renderActivitySummary() {
    // Count activities
    let requestCount = activitiesData.filter(a => a.type === 'request').length;
    let approvedCount = activitiesData.filter(a => a.type === 'approved').length;
    let declinedCount = activitiesData.filter(a => a.type === 'declined').length;
    
    document.getElementById("activityRequest").textContent = requestCount;
    document.getElementById("activityApproved").textContent = approvedCount;
    document.getElementById("activityDeclined").textContent = declinedCount;
}

function renderInventory(filter) {
    const table = document.getElementById("inventoryTable");
    table.innerHTML = "";
    let counts = { all:0, in:0, low:0, out:0 };

    inventoryData.forEach(i => {
        const status = getStatus(i.stock, i.min_stock);
        counts.all++;
        counts[status]++;

        if (filter !== 'all' && status !== filter) return;

        let statusClass = status === 'in' ? 'green' : status === 'low' ? 'yellow' : 'red';
        let statusText = status === 'in' ? 'In Stock' : status === 'low' ? 'Low Stock' : 'Out of Stock';
        const itemCode = `ITM${String(i.id).padStart(4, '0')}`;

        table.innerHTML += `
            <tr>
                <td>
                    <div class="item-cell">
                        <div class="item-img-box"></div>
                        <div class="item-text">
                            <div class="item-name">${i.item_name}</div>
                            <div class="item-code">${itemCode}</div>
                        </div>
                    </div>
                </td>
                <td>${i.category}</td>
                <td>${i.stock} ${i.unit || 'pcs'}</td>
                <td><span class="status ${statusClass}">${statusText}</span></td>
                <td>${i.last_modified}</td>
            </tr>
        `;
    });

    document.getElementById("totalItemCount").textContent = counts.all;
}

document.querySelectorAll(".clickable-stat").forEach(card => {
    card.onclick = () => renderInventory(card.dataset.filter);
});

// --- APPROVALS/REQUESTS LOGIC ---
function renderRequests(filter) {
    const table = document.getElementById("requestTable");
    table.innerHTML = "";
    
    let counts = { all: 0, pending: 0, approved: 0, declined: 0 };
    
    requestsData.forEach(req => {
        counts.all++;
        const reqStatus = req.status || 'Pending';
        counts[reqStatus.toLowerCase()]++;
    });
    
    document.getElementById("req-count-all").textContent = counts.all;
    document.getElementById("req-count-pending").textContent = counts.pending;
    document.getElementById("req-count-approved").textContent = counts.approved;
    document.getElementById("req-count-declined").textContent = counts.declined;
    
    requestsData.forEach((req, index) => {
        const reqStatus = (req.status || 'Pending').toLowerCase();
        if (filter !== 'all' && reqStatus !== filter.toLowerCase()) return;
        
        let statusClass = '';
        if (req.status === 'Approved') statusClass = 'request-status-approved';
        else if (req.status === 'Pending') statusClass = 'request-status-pending';
        else if (req.status === 'Declined') statusClass = 'request-status-declined';
        
        let stockClass = '';
        const stockStatus = req.stock_status || 'In Stock';
        if (stockStatus === 'In Stock') stockClass = 'stock-status-in';
        else if (stockStatus === 'Low Stock') stockClass = 'stock-status-low';
        else if (stockStatus === 'Out of Stock') stockClass = 'stock-status-out';
        
        // Format date
        const reqDate = new Date(req.request_date);
        const formattedDate = reqDate.getFullYear() + '-' + 
                             (reqDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                             reqDate.getDate().toString().padStart(2, '0');
        
        table.innerHTML += `
            <tr onclick="showRequestDetails(${req.id})">
                <td><span class="request-no">●${req.id || '-'}</span></td>
                <td>${req.item_name}</td>
                <td>${req.quantity}</td>
                <td>${req.requestor}</td>
                <td>${req.approver || '-'}</td>
                <td><span class="${stockClass}">${stockStatus}</span></td>
                <td><span class="${statusClass}">${req.status || 'Pending'}</span></td>
                <td>${formattedDate}</td>
                <td><button class="request-menu-btn" onclick="event.stopPropagation()">⋮</button></td>
            </tr>
        `;
    });
}

function showRequestDetails(requestId) {
    const req = requestsData.find(r => r.id === requestId);
    if (!req) return;
    
    const modal = document.getElementById("requestDetailsModal");
    
    document.getElementById("detailReqNo").textContent = String(req.id).padStart(3, '0');
    document.getElementById("detailReqStatus").textContent = req.status || 'Pending';
    document.getElementById("detailReqStatus").className = `request-status-badge status-${(req.status || 'Pending').toLowerCase()}-badge`;
    
    const reqDate = new Date(req.request_date);
    const formattedDate = reqDate.getFullYear() + '-' + 
                         (reqDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                         reqDate.getDate().toString().padStart(2, '0');
    document.getElementById("detailReqDate").textContent = formattedDate;
    
    document.getElementById("detailRequestor").textContent = req.requestor;
    document.getElementById("detailApprover").textContent = req.approver || '-';
    document.getElementById("detailItemName").textContent = req.item_name;
    document.getElementById("detailQty").textContent = req.quantity;
    document.getElementById("detailRemarks").textContent = req.stock_status || 'In Stock';
    document.getElementById("detailNote").textContent = req.note || '';
    
    // Store the request ID for approval/decline actions
    modal.dataset.requestId = req.id;
    modal.classList.add("active");
}

document.getElementById("closeRequestDetails").onclick = () => {
    document.getElementById("requestDetailsModal").classList.remove("active");
};

document.getElementById("requestDetailsModal").onclick = (e) => {
    if (e.target.id === "requestDetailsModal") {
        document.getElementById("requestDetailsModal").classList.remove("active");
    }
};

// Request action buttons
document.getElementById("approveRequestBtn").onclick = async () => {
    const modal = document.getElementById("requestDetailsModal");
    const requestId = modal.dataset.requestId;
    if (!requestId) return;
    
    if (confirm('Approve this request?')) {
        const result = await updateRequestStatus(requestId, 'Approved');
        if (result) {
            modal.classList.remove("active");
        }
    }
};

document.getElementById("declineRequestBtn").onclick = async () => {
    const modal = document.getElementById("requestDetailsModal");
    const requestId = modal.dataset.requestId;
    if (!requestId) return;
    
    if (confirm('Decline this request?')) {
        const result = await updateRequestStatus(requestId, 'Declined');
        if (result) {
            modal.classList.remove("active");
        }
    }
};

document.querySelectorAll(".request-tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".request-tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderRequests(tab.dataset.filter);
    };
});

// --- USER MANAGEMENT LOGIC ---
function renderUsers() {
    const table = document.getElementById("userTable");
    table.innerHTML = "";
    
    document.getElementById("totalUserCount").textContent = usersData.length;
    const currentUser = window.currentAdminUser || '';
    
    usersData.forEach(user => {
        const roleClass = user.role === 'Admin' ? 'role-admin' : 
                         user.role === 'Approver' ? 'role-approver' : 'role-requester';
        const currentClass = user.username === currentUser ? 'user-current' : '';
        
        table.innerHTML += `
            <tr class="${currentClass}">
                <td>
                    <div class="user-info">
                        <div class="user-avatar"></div>
                        <div class="user-details">
                            <div class="user-name">${user.name}</div>
                            <div class="user-email">${user.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="role-badge ${roleClass}">${user.role}</span></td>
                <td>${user.province}</td>
                <td>${user.lastActive}</td>
                <td>${user.dateAdded}</td>
                <td><button class="delete-user-btn" data-username="${user.username}">Delete</button></td>
            </tr>
        `;
    });

    table.querySelectorAll('.delete-user-btn').forEach(btn => {
        btn.onclick = () => deleteUser(btn.dataset.username);
    });
}

async function deleteUser(username) {
    if (!username) return;
    if (!confirm(`Delete account ${username}? This action cannot be undone.`)) return;

    try {
        const response = await fetch(`${loginApiBase}/delete_user.php`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || `Unable to delete user (HTTP ${response.status})`);
        }

        await fetchUsers();
        renderUsers();
        showToast(`User ${username} deleted successfully.`, 'success');
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not delete user.', 'error');
    }
}

const addUserModal = document.getElementById("addUserModal");
const closeAddUserModalBtn = document.getElementById("closeAddUserModal");
const cancelAddUserBtn = document.getElementById("cancelAddUserBtn");
const saveUserBtn = document.getElementById("saveUserBtn");

async function fetchUsers() {
    try {
        const response = await fetch(`${loginApiBase}/get_users.php`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            let errorText = 'Unable to load users';
            try {
                const errJson = await response.json();
                errorText = errJson.message || errorText;
            } catch (fetchError) {
                errorText = `${errorText} (HTTP ${response.status})`;
            }
            throw new Error(errorText);
        }

        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message || 'Unable to load users');
        }

        usersData = data.data.map(user => ({
            username: user.username,
            name: user.full_name,
            email: user.email,
            role: user.role,
            province: user.province,
            lastActive: user.last_login ? formatDateTime(user.last_login) : 'Never',
            dateAdded: formatDateTime(user.created_at)
        }));
    } catch (error) {
        console.error(error);
        alert(`Could not load users from the database. Please refresh the page.\n${error.message}`);
    }
}

function formatDateTime(value) {
    if (!value) return 'Never';
    const normalized = value.replace(' ', 'T');
    const date = new Date(normalized);
    return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function openAddUserModal() {
    addUserModal.classList.add("active");
    clearAddUserForm();
    document.getElementById("newUserUsername").focus();
}

function closeAddUserModal() {
    addUserModal.classList.remove("active");
    clearAddUserForm();
}

function clearAddUserForm() {
    document.getElementById("newUserUsername").value = "";
    document.getElementById("newUserPassword").value = "";
    document.getElementById("newUserEmail").value = "";
    document.getElementById("newUserFullname").value = "";
    document.getElementById("newUserRole").value = "Admin";
    document.getElementById("newUserProvince").value = "";
}

document.getElementById("addUserBtn").onclick = openAddUserModal;
closeAddUserModalBtn.onclick = closeAddUserModal;
cancelAddUserBtn.onclick = closeAddUserModal;
addUserModal.onclick = (e) => {
    if (e.target.id === "addUserModal") {
        closeAddUserModal();
    }
};

saveUserBtn.onclick = async () => {
    const username = document.getElementById("newUserUsername").value.trim();
    const password = document.getElementById("newUserPassword").value;
    const email = document.getElementById("newUserEmail").value.trim();
    const fullname = document.getElementById("newUserFullname").value.trim();
    const role = document.getElementById("newUserRole").value;
    const province = document.getElementById("newUserProvince").value.trim();

    if (!username || !password || !email || !fullname || !role || !province) {
        alert("Please fill in all required fields.");
        return;
    }

    if (!email.toLowerCase().endsWith("@gmail.com")) {
        alert("Please use a valid Gmail address.");
        return;
    }

    try {
        const response = await fetch(`${loginApiBase}/add_user.php`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                password,
                email,
                fullname,
                role,
                province
            })
        });

        let result;
        try {
            result = await response.json();
        } catch (jsonError) {
            result = null;
        }

        if (!response.ok || !result || !result.success) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            const errorMessage = result?.message || `Unable to add user (HTTP ${response.status})`;
            throw new Error(errorMessage);
        }

        await fetchUsers();
        renderUsers();
        closeAddUserModal();
        showToast('New user created successfully.', 'success');
    } catch (error) {
        showToast(error.message || 'Could not add user.', 'error');
        console.error(error);
    }
};

// --- NOTIFICATIONS LOGIC ---
const notificationBtn = document.getElementById("notificationBtn");
const notificationsPanel = document.getElementById("notificationsPanel");
const notificationOverlay = document.getElementById("notificationOverlay");
const closeNotificationsBtn = document.getElementById("closeNotifications");

function toggleNotifications() {
    notificationsPanel.classList.toggle("active");
    notificationOverlay.classList.toggle("active");
    if(notificationsPanel.classList.contains("active")) {
        renderNotifications("all");
    }
}

function closeNotifications() {
    notificationsPanel.classList.remove("active");
    notificationOverlay.classList.remove("active");
}

notificationBtn.onclick = toggleNotifications;
closeNotificationsBtn.onclick = closeNotifications;
notificationOverlay.onclick = closeNotifications;

document.querySelectorAll(".notif-tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".notif-tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderNotifications(tab.dataset.filter);
    };
});

function renderNotifications(filter) {
    const todayNotif = document.getElementById("todayNotifications");
    const olderNotif = document.getElementById("olderNotifications");
    todayNotif.innerHTML = "";
    olderNotif.innerHTML = "";
    
    const iconMap = {
        info: "ℹ️",
        warning: "⚠️",
        success: "✓",
        error: "✕",
        system: "⚙️"
    };
    
    notificationsData.forEach(notif => {
        if(filter !== "all" && notif.category !== filter) return;
        
        const notifHTML = `
            <div class="notif-item">
                <div class="notif-icon ${notif.type}">${iconMap[notif.type]}</div>
                <div class="notif-body">
                    <p class="notif-title">${notif.title}</p>
                    <p class="notif-message">${notif.message}</p>
                </div>
                <div style="display:flex; flex-direction:column; align-items:flex-end; gap:4px;">
                    <p class="notif-time">${notif.time}</p>
                    <div class="notif-indicator"></div>
                </div>
            </div>
        `;
        
        if(notif.isToday) {
            todayNotif.innerHTML += notifHTML;
        } else {
            olderNotif.innerHTML += notifHTML;
        }
    });
}

// --- DASHBOARD ARROWS ---
document.querySelectorAll(".dashboard-arrow").forEach(arrow => {
    arrow.onclick = (e) => {
        e.preventDefault();
        showPage(arrow.dataset.page);
        if(arrow.dataset.page === 'inventory') renderInventory(arrow.dataset.filter);
        if(arrow.dataset.page === 'approvals') {
            document.querySelector(`.tab[data-filter="${arrow.dataset.filter}"]`).click();
        }
    };
});

// --- API INTEGRATION HELPERS ---
// These functions serve as templates for connecting to your backend API.
// Uncomment and modify based on your backend endpoints.

/*
// Helper function for API requests with authentication
async function apiRequest(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if(session.token) {
        headers.Authorization = `Bearer ${session.token}`;
    }
    
    try {
        const response = await fetch(url, {
            ...options,
            headers
        });
        
        if(response.status === 401) {
            // Token expired or invalid
            logout();
            return null;
        }
        
        if(!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Request failed:', error);
        return null;
    }
}

// Fetch data from backend (replace hardcoded data)
async function loadAllData() {
    const baseURL = '/api'; // Update with your API URL
    
    // Fetch inventory
    const inventory = await apiRequest(`${baseURL}/inventory`);
    if(inventory) inventoryData = inventory;
    
    // Fetch requests
    const requests = await apiRequest(`${baseURL}/requests`);
    if(requests) requestsData = requests;
    
    // Fetch users
    const users = await apiRequest(`${baseURL}/users`);
    if(users) usersData = users;
    
    // Fetch activities
    const activities = await apiRequest(`${baseURL}/activities`);
    if(activities) activitiesData = activities;
}

// Add item to backend
async function addItemToBackend(itemData) {
    return await apiRequest('/api/inventory', {
        method: 'POST',
        body: JSON.stringify(itemData)
    });
}

// Approve/Decline request
async function updateRequestStatus(requestId, status, remarks) {
    return await apiRequest(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, remarks })
    });
}

// Add user to backend
async function addUserToBackend(userData) {
    return await apiRequest('/api/users', {
        method: 'POST',
        body: JSON.stringify(userData)
    });
}
*/

// --- INITIALIZE ---
async function initializeAdmin() {
    await fetchUsers();
    await fetchInventory();
    await fetchRequests();
    await fetchRecentRequests();
    renderUsers();
    renderInventory('all');
    renderRequests('all');
    renderRecentRequests();
    initDashboard();
    
    // Auto-refresh inventory and dashboard stats every 60 seconds
    setInterval(async () => {
        await fetchInventory();
        await fetchRequests();
        await fetchRecentRequests();
        if (document.getElementById('dashboard').classList.contains('active')) {
            renderDashboardStats();
            renderRecentRequests();
        }
        if (document.getElementById('inventory').classList.contains('active')) {
            renderInventory('all');
        }
        if (document.getElementById('approvals').classList.contains('active')) {
            renderRequests('all');
        }
    }, 60000);
}

async function fetchInventory() {
    try {
        const response = await fetch(`${inventoryApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load inventory (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load inventory');
        inventoryData = Array.isArray(data.data) ? data.data : [];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load inventory.', 'error');
        inventoryData = [];
    }
}

async function fetchRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load requests (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load requests');
        requestsData = Array.isArray(data.data) ? data.data : [];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load requests.', 'error');
        requestsData = [];
    }
}

async function fetchRecentRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=recent`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load recent requests (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load recent requests');
        recentRequestsData = Array.isArray(data.data) ? data.data.slice(0, 5) : [];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load recent requests.', 'error');
        recentRequestsData = [];
    }
}

async function updateRequestStatus(requestId, status) {
    try {
        const response = await fetch(`${requestsApiBase}?action=update_status`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: requestId, status: status })
        });
        
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to update request (HTTP ${response.status})`);
        }
        
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to update request');
        
        showToast(`Request ${status.toLowerCase()} successfully`, 'success');
        await fetchRequests();
        await fetchRecentRequests();
        renderRequests('all');
        renderRecentRequests();
        return true;
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not update request.', 'error');
        return false;
    }
}

initializeAdmin().then(() => {
    if (window.flashMessage) {
        showToast(window.flashMessage, 'success');
        window.flashMessage = '';
    }
});

const addModal = document.getElementById("addItemsModal");
if (addModal) {
    addModal.remove();
}

// --- SEARCH FUNCTIONALITY ---
function filterAndRenderInventory(searchQuery) {
    const query = searchQuery.toLowerCase().trim();
    const table = document.getElementById("inventoryTable");
    table.innerHTML = "";
    let counts = { all: 0, in: 0, low: 0, out: 0 };

    inventoryData.forEach(i => {
        const status = getStatus(i.stock, i.min_stock);
        const itemName = i.item_name.toLowerCase();
        const itemCode = `ITM${String(i.id).padStart(4, '0')}`.toLowerCase();
        const category = (i.category || '').toLowerCase();
        
        // Check if item matches search query
        const matches = !query || itemName.includes(query) || itemCode.includes(query) || category.includes(query);
        
        if (!matches) return;
        
        counts.all++;
        counts[status]++;

        let statusClass = status === 'in' ? 'green' : status === 'low' ? 'yellow' : 'red';
        let statusText = status === 'in' ? 'In Stock' : status === 'low' ? 'Low Stock' : 'Out of Stock';
        const formattedItemCode = `ITM${String(i.id).padStart(4, '0')}`;

        table.innerHTML += `
            <tr>
                <td>
                    <div class="item-cell">
                        <div class="item-img-box"></div>
                        <div class="item-text">
                            <div class="item-name">${i.item_name}</div>
                            <div class="item-code">${formattedItemCode}</div>
                        </div>
                    </div>
                </td>
                <td>${i.category}</td>
                <td>${i.stock} ${i.unit || 'pcs'}</td>
                <td><span class="status ${statusClass}">${statusText}</span></td>
                <td>${i.last_modified}</td>
            </tr>
        `;
    });

    document.getElementById("totalItemCount").textContent = counts.all;
}

// Add event listener to search input
const searchInput = document.getElementById("searchInput");
if (searchInput) {
    searchInput.addEventListener("input", (e) => {
        filterAndRenderInventory(e.target.value);
    });
}

// Add event listener to user search input
const userSearchInput = document.getElementById("userSearchInput");
if (userSearchInput) {
    userSearchInput.addEventListener("input", (e) => {
        filterAndRenderUsers(e.target.value);
    });
}

function filterAndRenderUsers(searchQuery) {
    const query = searchQuery.toLowerCase().trim();
    const table = document.getElementById("userTable");
    table.innerHTML = "";
    const currentUser = window.currentAdminUser || '';
    
    usersData.forEach(user => {
        const userName = user.name.toLowerCase();
        const userEmail = user.email.toLowerCase();
        const province = (user.province || '').toLowerCase();
        
        // Check if user matches search query
        const matches = !query || userName.includes(query) || userEmail.includes(query) || province.includes(query);
        
        if (!matches) return;
        
        const roleClass = user.role === 'Admin' ? 'role-admin' : 
                         user.role === 'Approver' ? 'role-approver' : 'role-requester';
        const currentClass = user.username === currentUser ? 'user-current' : '';
        
        table.innerHTML += `
            <tr class="${currentClass}">
                <td>
                    <div class="user-info">
                        <div class="user-avatar"></div>
                        <div class="user-details">
                            <div class="user-name">${user.name}</div>
                            <div class="user-email">${user.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="role-badge ${roleClass}">${user.role}</span></td>
                <td>${user.province}</td>
                <td>${user.lastActive}</td>
                <td>${user.dateAdded}</td>
                <td>
                    <button class="icon-btn" onclick="editUser('${user.id}')">✏️</button>
                    <button class="icon-btn" onclick="deleteUser('${user.id}')">🗑️</button>
                </td>
            </tr>
        `;
    });
}
