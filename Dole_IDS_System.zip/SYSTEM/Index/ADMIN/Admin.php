<?php
session_set_cookie_params(['path' => '/']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    header('Location: ../../Index/SUPPLY/Central.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOLE Inventory System</title>
    <link rel="stylesheet" href="Admin.css">
</head>
<body>

<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="../../Images/LOGO%20IN.png" alt="DOLE Logo">
            <div>
                <h3>Department of Labor</h3>
                <p>and Employment</p>
            </div>
        </div>
        <ul class="nav">
            <li class="active" data-page="dashboard"><span class="nav-icon"></span> Dashboard</li>
            <li data-page="usermanagement"><span class="nav-icon"></span> User Management</li>
            <li data-page="inventory"><span class="nav-icon"></span> Inventory</li>
            <li data-page="approvals"><span class="nav-icon"></span> Requests Management</li>
            <li data-page="reports"><span class="nav-icon"></span> Reports</li>
        </ul>
        <div class="nav-bottom">
            <li data-page="settings"><span class="nav-icon"></span> Settings</li>
            <li data-page="logout"><span class="nav-icon"></span> Log out</li>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <div class="topbar-left">
                <h2 id="page-title">Dashboard</h2>
                <p class="subtitle">Explore your needs here</p>
            </div>
            <div class="topbar-right">
                <div class="search-bar">
                    <span class="search-icon">🔍</span>
                    <input type="text" placeholder="Search anything...">
                </div>
                <button class="notification-btn" id="notificationBtn">🔔</button>
                <div class="profile">
                    <div class="avatar"></div>
                    <div class="profile-info">
                        <h4><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></h4>
                        <p><?php echo htmlspecialchars($_SESSION['role']); ?></p>
                    </div>
                </div>
            </div>
        </header>

        <!-- Notifications Panel -->
        <div class="notifications-panel" id="notificationsPanel">
            <div class="notifications-header">
                <h3>Notifications</h3>
                <button class="close-notifications" id="closeNotifications">✕</button>
            </div>
            <div class="notifications-tabs">
                <div class="notif-tab active" data-filter="all">All <span class="notif-count">9</span></div>
                <div class="notif-tab" data-filter="request">Request <span class="notif-count">4</span></div>
                <div class="notif-tab" data-filter="inventory">Inventory <span class="notif-count">5</span></div>
                <div class="notif-tab" data-filter="users">Users <span class="notif-count">0</span></div>
                <div class="notif-tab" data-filter="system">System <span class="notif-count">1</span></div>
            </div>
            <div class="notifications-content">
                <div class="notif-section">
                    <h4 class="notif-section-title">Today</h4>
                    <div id="todayNotifications" class="notif-list"></div>
                </div>
                <div class="notif-section">
                    <h4 class="notif-section-title">Older</h4>
                    <div id="olderNotifications" class="notif-list"></div>
                </div>
            </div>
            <button class="view-all-notif">View all</button>
        </div>

        <div class="notification-overlay" id="notificationOverlay"></div>

        <section id="dashboard" class="page active">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder blue">📦</span> TOTAL INVENTORY</div>
                    <h1 id="totalInventoryCount">14</h1>
                </div>
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder yellow">⚠️</span> LOW STOCK</div>
                    <h1 id="lowStockCount">05</h1>
                </div>
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder red">❌</span> OUT OF STOCK</div>
                    <h1 id="outStockCount">14</h1>
                </div>
            </div>

            <div class="dashboard-main">
                <div class="dashboard-left">
                    <!-- Recent Requests -->
                    <div class="dashboard-section">
                        <h3 class="section-title">Recent Requests</h3>
                        <table class="dashboard-table">
                            <thead>
                                <tr>
                                    <th>ITEM</th>
                                    <th>QUANTITY</th>
                                    <th>DATE</th>
                                    <th>STATUS</th>
                                    <th>REQUESTOR</th>
                                </tr>
                            </thead>
                            <tbody id="recentRequestsTable"></tbody>
                        </table>
                    </div>

                    <!-- Recent Activities -->
                    <div class="dashboard-section">
                        <h3 class="section-title">Recent Activities</h3>
                        <div id="recentActivitiesList" class="activities-list"></div>
                    </div>
                </div>

                <div class="dashboard-right">
                    <!-- Popular Requested Items -->
                    <div class="dashboard-section">
                        <h3 class="section-title">Popular Requested Items</h3>
                        <ul id="popularItemsList" class="popular-items-list"></ul>
                        <button class="view-all-btn">View all</button>
                    </div>

                    <!-- Activity Summary -->
                    <div class="dashboard-section">
                        <h3 class="section-title">Activity Summary (Today)</h3>
                        <div class="activity-summary">
                            <div class="summary-row">
                                <span class="summary-label">Request</span>
                                <span class="summary-value" id="activityRequest">1</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Approved</span>
                                <span class="summary-value" id="activityApproved">2</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Declined</span>
                                <span class="summary-value" id="activityDeclined">1</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="inventory" class="page">
            <div class="inventory-header">
                <div class="inventory-title-section">
                    <h3 class="inventory-title">All Items <span id="totalItemCount">14</span></h3>
                </div>
                <div class="inventory-actions">
                    <div class="search-wrapper">
                        <span class="search-icon">🔍</span>
                        <input id="searchInput" placeholder="Search">
                    </div>
                </div>
            </div>
            <div class="inventory-table-container">
                <table class="inventory-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>In Stock</th>
                            <th>Status</th>
                            <th>Last Modified</th>
                        </tr>
                    </thead>
                    <tbody id="inventoryTable"></tbody>
                </table>
            </div>
        </section>

        <section id="approvals" class="page">
            <div class="request-management-header">
                <div class="request-tabs">
                    <div class="request-tab active" data-filter="all">All <span id="req-count-all">13</span></div>
                    <div class="request-tab" data-filter="pending">Pending <span id="req-count-pending">15</span></div>
                    <div class="request-tab" data-filter="approved">Approved <span id="req-count-approved">03</span></div>
                    <div class="request-tab" data-filter="declined">Declined <span id="req-count-declined">02</span></div>
                </div>
                <div class="request-actions">
                    <button class="icon-btn-outline">✏️</button>
                    <button class="icon-btn-outline">≡</button>
                </div>
            </div>
            <div class="request-table-container">
                <table class="request-table">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Requestor</th>
                            <th>Approver</th>
                            <th>Stock status</th>
                            <th>Request status</th>
                            <th>Date Requested</th>
                            <th style="width: 50px;"></th>
                        </tr>
                    </thead>
                    <tbody id="requestTable"></tbody>
                </table>
            </div>
        </section>

        <section id="reports" class="page">
            <div class="reports-header">
                <div class="reports-title">
                    <h3 class="section-title">Reports</h3>
                    <p>Review usage, exports, and inventory trends.</p>
                </div>
                <div class="reports-actions">
                    <button class="blue-btn">Export PDF</button>
                    <button class="blue-btn">Download CSV</button>
                </div>
            </div>
            <div class="reports-grid">
                <div class="report-card">
                    <h4>Monthly Requests</h4>
                    <p>142 new requests this month</p>
                </div>
                <div class="report-card">
                    <h4>Stock Health</h4>
                    <p>68% of items are above minimum levels</p>
                </div>
                <div class="report-card">
                    <h4>Approval Rate</h4>
                    <p>83% approval across all requests</p>
                </div>
            </div>
        </section>

        <section id="system" class="page">
            <div class="system-header">
                <h3 class="section-title">System</h3>
                <p>System configuration, backup, and maintenance controls.</p>
            </div>
            <div class="system-panel">
                <div class="system-row">
                    <span>Server Status</span>
                    <strong>Online</strong>
                </div>
                <div class="system-row">
                    <span>Database</span>
                    <strong>Connected</strong>
                </div>
                <div class="system-row">
                    <span>Last Backup</span>
                    <strong>Today at 02:15 AM</strong>
                </div>
            </div>
        </section>

        <section id="usermanagement" class="page">
            <div class="user-management-header">
                <div class="user-title-section">
                    <h3 class="user-title">All users <span id="totalUserCount">0</span></h3>
                </div>
                <div class="user-actions">
                    <div class="search-wrapper">
                        <span class="search-icon">🔍</span>
                        <input id="userSearchInput" placeholder="Search">
                    </div>
                    <button id="addUserBtn" class="add-user-btn">👤 Add User</button>
                </div>
            </div>
            <div class="user-table-container">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Province</th>
                            <th>Last active</th>
                            <th>Date added</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="userTable"></tbody>
                </table>
            </div>
        </section>

        <section id="settings" class="page">
            <div class="settings-header">
                <h3 class="section-title">Settings</h3>
                <p>Configure basic system preferences.</p>
            </div>
            <div class="settings-grid">
                <div class="settings-card">
                    <h4>Theme</h4>
                    <p>Dark mode is currently disabled.</p>
                </div>
                <div class="settings-card">
                    <h4>Notifications</h4>
                    <p>Push notifications are enabled.</p>
                </div>
                <div class="settings-card">
                    <h4>Security</h4>
                    <p>Two-factor authentication is available.</p>
                </div>
            </div>
        </section>
    </main>
</div>

<div class="modal-overlay" id="addUserModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeAddUserModal">←</button>
            <h3>Create User Account</h3>
        </div>
        <div class="modal-body">
            <div class="form-row">
                <div class="form-group">
                    <label>Username <span class="req">*</span></label>
                    <input type="text" id="newUserUsername" placeholder="Username">
                </div>
                <div class="form-group">
                    <label>Password <span class="req">*</span></label>
                    <input type="password" id="newUserPassword" placeholder="Password">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Gmail <span class="req">*</span></label>
                    <input type="email" id="newUserEmail" placeholder="Gmail">
                </div>
                <div class="form-group">
                    <label>Fullname <span class="req">*</span></label>
                    <input type="text" id="newUserFullname" placeholder="Fullname">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Role <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newUserRole">
                            <option value="Admin">Admin</option>
                            <option value="Approver">Approver</option>
                            <option value="Requester">Requester</option>
                            <option value="Delivery">Delivery</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Province <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newUserProvince">
                            <option value="CAVITE">CAVITE</option>
                            <option value="LAGUNA">LAGUNA</option>
                            <option value="BATANGAS">BATANGAS</option>
                            <option value="RIZAL">RIZAL</option>
                            <option value="QUEZON">QUEZON</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelAddUserBtn">Cancel</button>
            <button class="btn-save" id="saveUserBtn">Create</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="requestDetailsModal">
    <div class="modal request-modal">
        <div class="modal-header">
            <h3>Request Details</h3>
            <button class="modal-back" id="closeRequestDetails">✕</button>
        </div>
        <div class="modal-body request-details-body">
            <div class="detail-row"><span>Request No:</span><strong id="detailReqNo">#001</strong></div>
            <div class="detail-row"><span>Status:</span><strong id="detailReqStatus">Pending</strong></div>
            <div class="detail-row"><span>Date:</span><strong id="detailReqDate">2026-04-10</strong></div>
            <div class="detail-row"><span>Requestor:</span><strong id="detailRequestor">Cavite</strong></div>
            <div class="detail-row"><span>Approver:</span><strong id="detailApprover">Flavio Deza IV</strong></div>
            <div class="detail-row"><span>Item:</span><strong id="detailItemName">Ballpoint Pen</strong></div>
            <div class="detail-row"><span>Quantity:</span><strong id="detailQty">8 pcs</strong></div>
            <div class="detail-row"><span>Remarks:</span><strong id="detailRemarks">Low Stock</strong></div>
            <div class="detail-row"><span>Note:</span><strong id="detailNote">Please process urgently.</strong></div>
        </div>
        <div class="modal-footer request-actions-footer">
            <button id="approveRequestBtn" class="blue-btn">✓ Approve</button>
            <button id="declineRequestBtn" class="red-btn">✕ Decline</button>
        </div>
    </div>
</div>

<div id="toastMessage" class="toast-message"></div>

<script>
    window.currentAdminUser = <?php echo json_encode($_SESSION['username'] ?? ''); ?>;
    window.flashMessage = <?php echo json_encode($_SESSION['flash_message'] ?? ''); ?>;
    <?php if (!empty($_SESSION['flash_message'])) unset($_SESSION['flash_message']); ?>
</script>
<script src="Admin.js"></script>

</body>
</html>
