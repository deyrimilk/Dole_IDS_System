// ============================================================
// PAGE MANAGEMENT
// ============================================================

/**
 * Shows the specified page and hides all others
 * @param {string} pageName - The name of the page to show (e.g., 'home', 'request', 'my-requests', 'deliveries')
 */
function showPage(pageName) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.add('hidden');
    });

    // Show selected page
    const selectedPage = document.getElementById(pageName + '-page');
    if (selectedPage) {
        selectedPage.classList.remove('hidden');
    }

    // Update navigation active state
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active');
    });

    const activeNav = document.getElementById('nav-' + pageName);
    if (activeNav) {
        activeNav.classList.add('active');
    }

    // Re-initialize filters if on request page
    if (pageName === 'request') {
        renderItems();
    }

    // Re-initialize requests if on my-requests page
    if (pageName === 'my-requests') {
        renderRequests();
    }
}

// ============================================================
// SAMPLE ITEMS DATA
// ============================================================
// TODO: Replace with data from backend/database

const items = [
    {
        id: 1,
        name: "Bond Paper (Short)",
        category: "Paper Products",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/bond-paper.jpg')
        image: "📄"
    },
    {
        id: 2,
        name: "Ballpoint Pen (Black)",
        category: "Writing Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/ballpoint-pen.jpg')
        image: "🖊️"
    },
    {
        id: 3,
        name: "Highlighter",
        category: "Writing Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/highlighter.jpg')
        image: "🖍️"
    },
    {
        id: 4,
        name: "Ink (Black)",
        category: "Office Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/ink-black.jpg')
        image: "🖨️"
    },
    {
        id: 5,
        name: "Folder (Expandable)",
        category: "Office Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/folder-expandable.jpg')
        image: "📁"
    },
    {
        id: 6,
        name: "Printer Paper",
        category: "Paper Products",
        status: "Low Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/printer-paper.jpg')
        image: "📋"
    },
    {
        id: 7,
        name: "Gel Pen (Blue)",
        category: "Writing Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/gel-pen-blue.jpg')
        image: "✏️"
    },
    {
        id: 8,
        name: "Stapler",
        category: "Office Equipment",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/stapler.jpg')
        image: "📎"
    },
    {
        id: 9,
        name: "Scotch Tape",
        category: "Office Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/scotch-tape.jpg')
        image: "🎗️"
    },
    {
        id: 10,
        name: "Envelope (A4)",
        category: "Paper Products",
        status: "Low Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/envelope-a4.jpg')
        image: "✉️"
    },
    {
        id: 11,
        name: "Desk Lamp",
        category: "Office Equipment",
        status: "Out of Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/desk-lamp.jpg')
        image: "💡"
    },
    {
        id: 12,
        name: "Index Card",
        category: "Paper Products",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/index-card.jpg')
        image: "📇"
    },
    {
        id: 13,
        name: "Eraser",
        category: "Writing Supplies",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/eraser.jpg')
        image: "🧹"
    },
    {
        id: 14,
        name: "Pencil Set",
        category: "Writing Supplies",
        status: "Low Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/pencil-set.jpg')
        image: "🖍️"
    },
    {
        id: 15,
        name: "Cabinet Organizer",
        category: "Office Equipment",
        status: "In Stock",
        // PLACEHOLDER: Admin should replace with actual image URL (e.g., '/images/items/cabinet-organizer.jpg')
        image: "🗄️"
    }
];

// ============================================================
// MY REQUESTS PAGE - DATA & RENDERING
// ============================================================
// TODO: Replace with data from backend/database

const requests = [
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Pending',
        fullItems: ['Epson 664 Cyan', 'Epson 664 Black', 'Bond Paper']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Approved',
        fullItems: ['Epson 664 Cyan', 'Epson 664 Black']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Approved',
        fullItems: ['Epson 664 Cyan', 'Ballpoint Pen', 'Highlighter']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Declined',
        fullItems: ['Desk Lamp', 'Cabinet Organizer']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Pending',
        fullItems: ['Epson 664 Cyan', 'Stapler']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Approved',
        fullItems: ['Eraser', 'Pencil Set']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Approved',
        fullItems: ['Scotch Tape', 'Envelope']
    },
    {
        id: 'RIS#2026-04-096',
        items: 'Epson 664, Cyan...',
        dateRequested: '03-01-26',
        purpose: 'Supply',
        status: 'Declined',
        fullItems: ['Ink Black', 'Folder']
    }
];

// Get DOM elements for My Requests page
const requestsContainer = document.getElementById('requestsContainer');
const requestsSearchInput = document.getElementById('requestsSearchInput');
const requestsStatusFilter = document.getElementById('requestsStatusFilter');

/**
 * Render requests to the DOM
 * @param {array} requestsToRender - Array of requests to display (defaults to all requests)
 */
function renderRequests(requestsToRender = requests) {
    requestsContainer.innerHTML = '';

    requestsToRender.forEach((request, index) => {
        const requestCard = createRequestCard(request, index);
        requestsContainer.appendChild(requestCard);
    });
}

/**
 * Create a request card element
 * @param {object} request - The request object
 * @param {number} index - The index of the request
 * @returns {HTMLElement} The request card element
 */
function createRequestCard(request, index) {
    const card = document.createElement('div');
    card.className = 'request-card';
    card.dataset.status = request.status;
    card.dataset.id = request.id.toLowerCase();

    // Determine status class for styling
    let statusClass = '';
    if (request.status === 'Pending') {
        statusClass = 'status-pending';
    } else if (request.status === 'Approved') {
        statusClass = 'status-approved';
    } else if (request.status === 'Delivered') {
        statusClass = 'status-delivered';
    } else if (request.status === 'Declined') {
        statusClass = 'status-rejected';
    }

    card.innerHTML = `
        <div class="request-header">
            <div class="request-id">${request.id}</div>
        </div>
        <div class="request-content">
            <div class="request-row">
                <label class="request-label">Items</label>
                <div class="request-value">${request.items}</div>
            </div>
            <div class="request-row">
                <label class="request-label">Date Requested</label>
                <div class="request-value">${request.dateRequested}</div>
            </div>
            <div class="request-row">
                <label class="request-label">Purpose</label>
                <div class="request-value">${request.purpose}</div>
            </div>
            <div class="request-footer">
                <span class="status-badge ${statusClass}">${request.status}</span>
            </div>
        </div>
    `;

    return card;
}

/**
 * Filter requests based on search and status
 */
function filterRequests() {
    const searchTerm = requestsSearchInput.value.toLowerCase();
    const selectedStatus = requestsStatusFilter.value;

    const filteredRequests = requests.filter(request => {
        const matchesSearch = request.id.toLowerCase().includes(searchTerm) || 
                            request.items.toLowerCase().includes(searchTerm);
        const matchesStatus = !selectedStatus || request.status === selectedStatus;

        return matchesSearch && matchesStatus;
    });

    renderRequests(filteredRequests);
}

// Get DOM elements
const itemsContainer = document.getElementById('itemsContainer');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const statusFilter = document.getElementById('statusFilter');

/**
 * Render items to the DOM
 * @param {array} itemsToRender - Array of items to display (defaults to all items)
 */
function renderItems(itemsToRender = items) {
    itemsContainer.innerHTML = '';

    itemsToRender.forEach(item => {
        const itemCard = createItemCard(item);
        itemsContainer.appendChild(itemCard);
    });
}

/**
 * Create an item card element
 * @param {object} item - The item object
 * @returns {HTMLElement} The item card element
 */
function createItemCard(item) {
    const card = document.createElement('div');
    card.className = 'item-card';
    card.dataset.category = item.category;
    card.dataset.status = item.status;
    card.dataset.name = item.name.toLowerCase();

    // Determine status indicator color
    let statusClass = '';
    if (item.status === 'Low Stock') {
        statusClass = 'low-stock';
    } else if (item.status === 'Out of Stock') {
        statusClass = 'out-of-stock';
    }

    card.innerHTML = `
        <div class="item-image">
            <!-- PLACEHOLDER: Replace with actual product image when admin uploads: <img src="${item.image}" alt="${item.name}" class="item-img"> -->
            <span style="font-size: 60px;" class="item-placeholder-icon" title="Placeholder - Admin will replace with actual image">${item.image}</span>
        </div>
        <div class="item-content">
            <div class="item-name">${item.name}</div>
            <div class="item-status">
                <span class="status-indicator ${statusClass}"></span>
                <span>${item.status}</span>
            </div>
            <div class="item-buttons">
                <!-- PLACEHOLDER: Cart icon - will be replaced with actual UI in future -->
                <button class="item-btn add-cart-btn" title="Add to Cart" onclick="addToCart(${item.id})" aria-label="Add to cart">🛒</button>
                <!-- Request item button -->
                <button class="item-btn request-btn" onclick="requestItem(${item.id})">Request Item Now</button>
            </div>
        </div>
    `;

    return card;
}

/**
 * Filter items based on search, category, and status
 */
function filterItems() {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedCategory = categoryFilter.value;
    const selectedStatus = statusFilter.value;

    const filteredItems = items.filter(item => {
        const matchesSearch = item.name.toLowerCase().includes(searchTerm);
        const matchesCategory = !selectedCategory || item.category === selectedCategory;
        const matchesStatus = !selectedStatus || item.status === selectedStatus;

        return matchesSearch && matchesCategory && matchesStatus;
    });

    renderItems(filteredItems);
}

/**
 * TODO: Add to cart functionality
 * @param {number} itemId - The ID of the item to add to cart
 */
function addToCart(itemId) {
    console.log('Add to cart clicked for item:', itemId);
    // TODO: Implement add to cart logic
    // - Store item in cart (localStorage or state management)
    // - Show notification/confirmation
    // - Update cart icon/count
    alert('Add to cart functionality to be implemented');
}

/**
 * TODO: Request item functionality
 * @param {number} itemId - The ID of the item to request
 */
function requestItem(itemId) {
    console.log('Request item clicked for item:', itemId);
    // TODO: Implement request item logic
    // - Show request form/modal
    // - Send request to backend
    // - Add to my requests table
    alert('Request item functionality to be implemented');
}

// ============================================================
// EVENT LISTENERS - REQUEST ITEM PAGE
// ============================================================

searchInput.addEventListener('input', filterItems);
categoryFilter.addEventListener('change', filterItems);
statusFilter.addEventListener('change', filterItems);

// ============================================================
// EVENT LISTENERS - MY REQUESTS PAGE
// ============================================================

requestsSearchInput.addEventListener('input', filterRequests);
requestsStatusFilter.addEventListener('change', filterRequests);

// ============================================================
// INITIALIZATION
// ============================================================

// Default to Home page on load
showPage('home');
