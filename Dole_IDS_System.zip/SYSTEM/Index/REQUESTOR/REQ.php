<?php
session_set_cookie_params(['path' => '/']);
session_start();
if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Requester') !== 0) {
    if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Admin') === 0) {
        header('Location: ../../Index/ADMIN/Admin.php');
    } elseif (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Approver') === 0) {
        header('Location: ../../Index/SUPPLY/Central.php');
    } else {
        header('Location: ../../Login/login.php');
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department of Labor and Employment - Supply Management System</title>
    <link rel="stylesheet" href="REQ.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <div class="logo-section">
                <div class="logo-placeholder" title="Department of Labor and Employment logo">
                    <img src="../../Images/LOGO%20IN.png" alt="DOLE Logo" class="logo-img">
                </div>
                <div class="header-text">
                    <h1>Department of Labor </h1>
                    <h1>and Employment</h1>
                </div>
            </div>
            <nav class="navigation">
                <!-- Navigation items - click handlers in JavaScript -->
                <a href="javascript:void(0)" onclick="showPage('home')" class="nav-link active" id="nav-home">Home</a>
                <a href="javascript:void(0)" onclick="showPage('request')" class="nav-link" id="nav-request">Request Item</a>
                <a href="javascript:void(0)" onclick="showPage('my-requests')" class="nav-link" id="nav-my-requests">My Requests</a>
                <a href="javascript:void(0)" onclick="showPage('deliveries')" class="nav-link" id="nav-deliveries">Deliveries</a>
            </nav>
            <div class="header-actions">
                <!-- Upload PPMP button -->
                <button class="upload-btn">Upload PPMP</button>
                <!-- PLACEHOLDER: Notification icon - to be replaced with actual icon -->
                <div class="notification-icon" title="Placeholder notification icon">🔔</div>
                <!-- PLACEHOLDER: Shopping cart icon - to be replaced with actual icon -->
                <div class="cart-icon" title="Placeholder shopping cart icon">🛒</div>
                <!-- PLACEHOLDER: Profile icon - to be replaced with actual icon -->
                <div class="profile-icon" title="Placeholder profile icon">👤</div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">

        <!-- HOME PAGE -->
        <div id="home-page" class="page">
            <div class="home-hero">
                <div class="home-hero-content">
                    <h3>Welcome to the Department of Labor and Employment Supply Management System</h3>
                    <p>Start here to manage your requests, track deliveries, and stay updated.</p>
                </div>
            </div>

            <section class="popular-section">
                <div class="section-header">
                    <h3>POPULAR REQUESTED ITEM</h3>
                </div>
                <div class="popular-grid">
                    <article class="popular-card">
                        <div class="popular-card-image"><img src="../../Images/REQ%20HP.png" alt="Bond Paper (Short)"></div>
                        <div class="popular-card-body">
                            <strong>Bond Paper (Short)</strong>
                            <span class="item-status available">Available</span>
                        </div>
                        <button class="popular-card-btn">Request Item Now</button>
                    </article>
                    <article class="popular-card">
                        <div class="popular-card-image"><img src="../../Images/REQ%20HP.png" alt="Ballpoint Pen (Black)"></div>
                        <div class="popular-card-body">
                            <strong>Ballpoint Pen (Black)</strong>
                            <span class="item-status available">Available</span>
                        </div>
                        <button class="popular-card-btn">Request Item Now</button>
                    </article>
                    <article class="popular-card">
                        <div class="popular-card-image"><img src="../../Images/REQ%20HP.png" alt="Highlighter"></div>
                        <div class="popular-card-body">
                            <strong>Highlighter</strong>
                            <span class="item-status available">Available</span>
                        </div>
                        <button class="popular-card-btn">Request Item Now</button>
                    </article>
                    <article class="popular-card">
                        <div class="popular-card-image"><img src="../../Images/REQ%20HP.png" alt="Ink (Black)"></div>
                        <div class="popular-card-body">
                            <strong>Ink (Black)</strong>
                            <span class="item-status available">Available</span>
                        </div>
                        <button class="popular-card-btn">Request Item Now</button>
                    </article>
                    <article class="popular-card">
                        <div class="popular-card-image"><img src="../../Images/REQ%20HP.png" alt="Folder (Expandable)"></div>
                        <div class="popular-card-body">
                            <strong>Folder (Expandable)</strong>
                            <span class="item-status available">Available</span>
                        </div>
                        <button class="popular-card-btn">Request Item Now</button>
                    </article>
                </div>
            </section>

            <footer class="home-footer">
                <div class="footer-grid">
                    <div class="footer-block footer-about">
                        <div class="footer-logo">DOLE</div>
                        <p>DOLE-IDS is designed to streamline inventory management and ensure efficient, transparent distribution of supplies across DOLE Region IV-A.</p>
                    </div>
                    <div class="footer-block footer-info">
                        <h4>SYSTEM INFO</h4>
                        <p>Department of Labor and Employment – Region IV-A</p>
                        <p>DOLE-IDS: Inventory and Distribution System</p>
                    </div>
                    <div class="footer-block footer-contact">
                        <h4>CONTACT INFO</h4>
                        <p>Calamba City, Laguna, Km 50 Manila S Rd, Real, Calamba, 4029 Laguna, Andenson Building 2</p>
                        <p>(049) 545-7362</p>
                        <p>ro4a_laguna@dole.gov.ph</p>
                        <p>Monday to Friday, 8:00 AM to 5:00 PM</p>
                    </div>
                </div>
                <div class="footer-bottom">
                    © 2026 DOLE.
                </div>
            </footer>
        </div>

        <!-- REQUEST ITEM PAGE -->
        <div id="request-page" class="page hidden">
            <div class="page-title">
                <h2>Request Item</h2>
            </div>

            <!-- Search and Filters Section -->
            <div class="filters-section">
                <div class="search-bar">
                    <!-- PLACEHOLDER: Search icon - to be replaced with actual icon -->
                    <span class="search-icon" title="Placeholder search icon">🔍</span>
                    <input type="text" id="searchInput" placeholder="Search" class="search-input">
                </div>
                
                <div class="filter-group">
                    <div class="filter-item">
                        <label>Category</label>
                        <select id="categoryFilter" class="dropdown">
                            <option value="">All Categories</option>
                            <option value="Paper Products">Paper Products</option>
                            <option value="Writing Supplies">Writing Supplies</option>
                            <option value="Office Supplies">Office Supplies</option>
                            <option value="Office Equipment">Office Equipment</option>
                        </select>
                    </div>
                    
                    <div class="filter-item">
                        <label>Status</label>
                        <select id="statusFilter" class="dropdown">
                            <option value="">All Status</option>
                            <option value="In Stock">In Stock</option>
                            <option value="Low Stock">Low Stock</option>
                            <option value="Out of Stock">Out of Stock</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Items Grid -->
            <div class="items-container" id="itemsContainer">
                <!-- Items will be generated here by JavaScript -->
            </div>
        </div>

        <!-- MY REQUESTS PAGE -->
        <div id="my-requests-page" class="page hidden">
            <div class="page-title">
                <h2>My Requests</h2>
            </div>

            <!-- Search and Filters Section for My Requests -->
            <div class="filters-section">
                <div class="search-bar">
                    <!-- PLACEHOLDER: Search icon - to be replaced with actual icon -->
                    <span class="search-icon" title="Placeholder search icon">🔍</span>
                    <input type="text" id="requestsSearchInput" placeholder="Search" class="search-input">
                </div>
                
                <div class="filter-group">
                    <div class="filter-item">
                        <label>Status</label>
                        <select id="requestsStatusFilter" class="dropdown">
                            <option value="">All Status</option>
                            <option value="Pending">Pending</option>
                            <option value="Approved">Approved</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Declined">Declined</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Requests Container - Grid Layout -->
            <div class="requests-container" id="requestsContainer">
                <!-- Request cards will be generated here by JavaScript -->
            </div>
        </div>

        <!-- DELIVERIES PAGE -->
        <div id="deliveries-page" class="page hidden">
            <div class="page-title">
                <h2>Deliveries</h2>
            </div>

            <!-- TODO: Add deliveries content here -->
            <div style="background-color: white; padding: 40px; border-radius: 8px; text-align: center; color: #999;">
                <p>Deliveries content coming soon...</p>
            </div>
        </div>

    </main>

    <script src="REQ.js"></script>
</body>
</html>
