// --- CENTRAL DATA ---
let inventoryData = [];

// Placeholder for Request Approval Data (No requests for now as requested)
const approvalsData = [];

// --- NAVIGATION ---
const navItems = document.querySelectorAll(".nav li, .nav-bottom li");
const pages = document.querySelectorAll(".page");
const userRole = String(window.currentUserRole || '').toLowerCase();
const canManageInventory = userRole === 'approver';
const canViewInventory = userRole === 'approver' || userRole === 'requester';
const appRoot = window.location.pathname.split('/').slice(0, 2).join('/') || '';
const inventoryApiBase = `${window.location.origin}${appRoot}/Inventory/inventory.php`;

navItems.forEach(item => {
    item.onclick = () => {
        if (item.dataset.page === 'logout') {
            logout();
        } else {
            showPage(item.dataset.page);
        }
    };
});

function showPage(pageId) {
    pages.forEach(p => p.classList.remove("active"));
    navItems.forEach(n => n.classList.remove("active"));
    
    if (pageId === 'inventory' && !canViewInventory) {
        pageId = 'dashboard';
    }

    document.getElementById(pageId).classList.add("active");
    document.querySelector(`.nav li[data-page="${pageId}"], .nav-bottom li[data-page="${pageId}"]`).classList.add("active");
    document.getElementById("page-title").textContent = pageId.charAt(0).toUpperCase() + pageId.slice(1);
    
    const titleMap = {
        dashboard: 'Dashboard',
        inventory: 'Inventory',
        notifications: 'Notifications',
        approvals: 'Request Approvals',
        delivery: 'Delivery Status'
    };
    document.getElementById("page-title").textContent = titleMap[pageId] || pageId.charAt(0).toUpperCase() + pageId.slice(1);

    if(pageId === 'dashboard') initDashboard();
    if(pageId === 'inventory') renderInventory('all');
    if(pageId === 'approvals') renderApprovals('all');
}

function showToast(message, type = 'success') {
    let toast = document.getElementById('toastMessage');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toastMessage';
        toast.className = 'toast-message';
        document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.className = `toast-message toast-${type} show`;
    clearTimeout(toast.hideTimer);
    toast.hideTimer = setTimeout(() => {
        toast.className = `toast-message toast-${type}`;
    }, 3200);
}

// --- CLOCK ---
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent = now.toLocaleString('en-US', { 
        weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' 
    });
}
setInterval(updateClock, 1000);

// --- DASHBOARD LOGIC (Link to Inventory) ---
function initDashboard() {
    const lowList = document.getElementById("lowStockList");
    const outList = document.getElementById("outStockList");
    lowList.innerHTML = "";
    outList.innerHTML = "";

    const lowItems = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').slice(0, 5);
    const outItems = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').slice(0, 5);

    lowItems.forEach(i => {
        lowList.innerHTML += `<li>${i.item_name} <span>↓ ${i.min_stock > 0 ? Math.floor((i.stock/i.min_stock)*100) : 0}%</span></li>`;
    });
    outItems.forEach(i => {
        outList.innerHTML += `<li>${i.item_name} <span>↓ 100%</span></li>`;
    });
}

// --- INVENTORY LOGIC ---
function renderInventory(filter = 'all') {
    const table = document.getElementById("inventoryTable");
    if (!table) return;

    table.innerHTML = "";
    let counts = { all: 0, in: 0, low: 0, out: 0 };
    const keyword = (document.getElementById("searchInput")?.value || '').trim().toLowerCase();

    inventoryData.forEach((item, index) => {
        const status = getStatus(item.stock, item.min_stock);
        counts.all++;
        counts[status]++;

        const matchesFilter = filter === 'all' || filter === status;
        const matchesSearch = !keyword
            || item.item_name.toLowerCase().includes(keyword)
            || item.category.toLowerCase().includes(keyword);
        if (!matchesFilter || !matchesSearch) return;

        const statusClass = status === 'in' ? 'green' : status === 'low' ? 'yellow' : 'red';
        const statusText = status === 'in' ? 'In Stock' : status === 'low' ? 'Low Stock' : 'Out of Stock';
        const itemCode = `ITM${String(item.id).padStart(4, '0')}`;

        table.innerHTML += `
            <tr>
                <td>
                    <div class="item-cell">
                        <div class="item-img-box"></div>
                        <div class="item-text">
                            <div class="item-name">${item.item_name}</div>
                            <div class="item-code">${itemCode}</div>
                        </div>
                    </div>
                </td>
                <td>${item.category}</td>
                <td>${item.stock} ${item.unit || 'pcs'}</td>
                <td><span class="status ${statusClass}">${statusText}</span></td>
                <td>${item.last_modified}</td>
                <td>
                    ${canManageInventory
                        ? `<div class="stock-actions">
                                <button class="manage-stock-btn" type="button" onclick="updateStock(${index})">Update Stock ↟</button>
                                <button class="remove-stock-btn" type="button" onclick="removeStock(${index})">Remove Stock ↡</button>
                           </div>`
                        : `<span class="status">View only</span>`
                    }
                </td>
            </tr>
        `;
    });

    const totalItemCount = document.getElementById("totalItemCount");
    if (totalItemCount) {
        totalItemCount.textContent = counts.all;
    }
}

function updateInventoryDependencies() {
    updateDashboardLists();
    renderInventory('all');
}

window.updateStock = function updateStock(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextStock = prompt(`Enter new stock for "${item.item_name}"`, String(item.stock));
    if (nextStock === null) return;
    const parsed = Number(nextStock);
    if (!Number.isFinite(parsed) || parsed < 0) {
        showToast('Please enter a valid stock number.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=updateStock`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: item.id, stock: Math.floor(parsed) })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to update stock');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Stock updated successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not update stock.', 'error');
        }
    })();
};

window.removeStock = function removeStock(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextRemove = prompt(`Remove how many from "${item.item_name}"? (Current: ${item.stock})`, "1");
    if (nextRemove === null) return;
    const qty = Number(nextRemove);

    if (!Number.isFinite(qty) || qty <= 0) {
        showToast('Please enter a valid quantity to remove.', 'error');
        return;
    }

    const newStock = item.stock - Math.floor(qty);
    if (newStock < 0) {
        showToast('Cannot remove more than current stock.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=updateStock`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: item.id, stock: newStock })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to remove stock');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Stock removed successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not remove stock.', 'error');
        }
    })();
};

window.editInventoryItem = function editInventoryItem(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextName = prompt('Edit item name', item.item_name);
    if (nextName === null) return;
    const nextCategory = prompt('Edit category', item.category);
    if (nextCategory === null) return;
    const nextMin = prompt('Edit minimum stock', String(item.min_stock));
    if (nextMin === null) return;

    const parsedMin = Number(nextMin);
    if (!nextName.trim() || !nextCategory.trim() || !Number.isFinite(parsedMin) || parsedMin < 0) {
        showToast('Please provide valid item details.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=update`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: item.id,
                    item_name: nextName.trim(),
                    category: nextCategory.trim(),
                    min_stock: Math.floor(parsedMin)
                })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to update item');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Item updated successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not update item.', 'error');
        }
    })();
};

window.deleteInventoryItem = function deleteInventoryItem(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;
    if (!confirm(`Delete "${item.item_name}" from inventory?`)) return;

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=delete`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: item.id })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to delete item');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Item deleted successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not delete item.', 'error');
        }
    })();
};

// (Row action menu removed; Central now uses "Update Stock" button like the previous Admin design.)

// --- APPROVALS LOGIC ---
function renderApprovals(filter) {
    const grid = document.getElementById("approvalsGrid");
    grid.innerHTML = "";

    // Count logical categories (even if empty)
    const counts = { all: 0, today: 0, pending: 0, approved: 0, declined: 0 };
    
    approvalsData.forEach(r => {
        counts.all++;
        counts[r.type]++;
    });

    // Update the UI numbers
    Object.keys(counts).forEach(key => {
        const el = document.getElementById(`cnt-${key}`);
        if(el) el.textContent = counts[key].toString().padStart(2, '0');
    });

    // If empty, show placeholders
    if (approvalsData.length === 0) {
        grid.innerHTML = `<p style="color:#aaa; grid-column: 1/-1; text-align:center; padding: 50px;">No requests found for this category.</p>`;
        return;
    }

    // Date color logic based on type
    const dateClasses = { today: 'date-today', pending: 'date-pending', approved: 'date-approved', declined: 'date-declined' };

    approvalsData.filter(r => filter === 'all' || r.type === filter).forEach(r => {
        grid.innerHTML += `
            <div class="req-card">
                <div class="req-header"><span>RN: ${r.rn}</span> <span>↗</span></div>
                <div class="req-row"><span class="req-label">Item:</span><span class="req-val">${r.item} x${r.qty}</span></div>
                <div class="req-row"><span class="req-label">Date Requested:</span><span class="req-val ${dateClasses[r.type]}">${r.date}</span></div>
                <div class="req-row"><span class="req-label">From:</span><span class="req-val">${r.branch}</span></div>
                <div class="req-row"><span class="req-label">Reason:</span><span class="req-val">${r.reason}</span></div>
            </div>
        `;
    });
}

document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderApprovals(tab.dataset.filter);
    };
});

// --- DASHBOARD ARROWS ---
document.querySelectorAll(".dashboard-arrow").forEach(arrow => {
    arrow.onclick = (e) => {
        e.preventDefault();
        showPage(arrow.dataset.page);
        if (arrow.dataset.page === 'inventory') {
            renderInventory(arrow.dataset.filter || 'all');
        }
        if(arrow.dataset.page === 'approvals') {
            document.querySelector(`.tab[data-filter="${arrow.dataset.filter}"]`).click();
        }
    };
});

// Initialize
updateClock();
initDashboard();
renderApprovals('all');

if (window.flashMessage) {
    showToast(window.flashMessage, 'success');
    window.flashMessage = '';
}

// --- LOGOUT FUNCTIONALITY ---
function logout() {
    window.location.href = '../../Login/logout.php';
}

// --- DASHBOARD LIST LOGIC ---
function updateDashboardLists() {
    const lowList = document.getElementById("lowStockList");
    const outList = document.getElementById("outStockList");
    
    lowList.innerHTML = "";
    outList.innerHTML = "";

    // Show first 5 items
    inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').slice(0, 5).forEach(i => {
        lowList.innerHTML += `<li>${i.item_name} <span>↓ ${i.min_stock > 0 ? Math.round((i.stock/i.min_stock)*100) : 0}%</span></li>`;
    });

    inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').slice(0, 5).forEach(i => {
        outList.innerHTML += `<li>${i.item_name} <span>↓ 100%</span></li>`;
    });
}
// --- HELPER FUNCTIONS ---
function getStatus(stock, min) {
    if (stock <= 0) return "out";
    if (stock <= min) return "low";
    return "in";
}
// --- MODAL LOGIC ---
const addModal = document.getElementById("addItemsModal");
const dropZone = document.getElementById("dropZone");
const fileInput = document.getElementById("fileInput");

if (addModal && dropZone && fileInput) {
    const addBtn = document.getElementById("addItemBtn");
    if (addBtn) {
        if (canManageInventory) {
            addBtn.onclick = () => addModal.classList.add("active");
        } else {
            addBtn.style.display = 'none';
        }
    }

    function closeModal() {
        addModal.classList.remove("active");
    }

    document.getElementById("closeModal").onclick = closeModal;
    document.getElementById("cancelBtn").onclick = closeModal;

    dropZone.onclick = () => fileInput.click();

    dropZone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropZone.classList.add("dragover");
    });

    dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));

    dropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZone.classList.remove("dragover");
        const files = e.dataTransfer.files;
        if (files.length) handleFileUpload(files[0]);
    });

    fileInput.onchange = () => {
        if (fileInput.files.length) handleFileUpload(fileInput.files[0]);
    };

    function handleFileUpload(file) {
        if (file.type.startsWith("image/")) {
            dropZone.querySelector("p").textContent = `Selected: ${file.name}`;
            dropZone.style.borderColor = "#4f7cff";
        }
    }

    document.getElementById("saveBtn").onclick = () => {
        const name = document.getElementById("newItemName").value.trim();
        const stock = parseInt(document.getElementById("newItemStock").value, 10) || 0;
        const min = parseInt(document.getElementById("newItemMin").value, 10) || 0;
        const cat = document.getElementById("newItemCategory").value;

        if (name && cat) {
            (async () => {
                try {
                    const response = await fetch(`${inventoryApiBase}?action=add`, {
                        method: 'POST',
                        credentials: 'include',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            item_name: name,
                            category: cat,
                            stock,
                            min_stock: min
                        })
                    });
                    const data = await response.json();
                    if (!response.ok || !data.success) throw new Error(data.message || 'Unable to add item');
                    await fetchInventory();
                    updateInventoryDependencies();
                    closeModal();
                    showToast("Item added successfully!", 'success');
                } catch (err) {
                    showToast(err.message || 'Could not add item.', 'error');
                }
            })();
        } else {
            showToast("Please fill in the required fields (*).", 'error');
        }
    };
}

// --- INITIALIZE ---
updateDashboardLists();
renderInventory('all');

async function fetchInventory() {
    try {
        const response = await fetch(`${inventoryApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) throw new Error(`Unable to load inventory (HTTP ${response.status})`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load inventory');
        inventoryData = Array.isArray(data.data) ? data.data : [];
    } catch (err) {
        inventoryData = [];
        showToast(err.message || 'Could not load inventory.', 'error');
    }
}

(async () => {
    await fetchInventory();
    updateInventoryDependencies();
    initDashboard();
})();

const searchInput = document.getElementById("searchInput");
if (searchInput) {
    searchInput.addEventListener("input", () => renderInventory('all'));
}

if (!canViewInventory) {
    document.querySelector('.nav li[data-page="inventory"]')?.remove();
}

