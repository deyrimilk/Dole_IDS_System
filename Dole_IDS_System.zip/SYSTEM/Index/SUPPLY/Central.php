<?php
session_set_cookie_params(['path' => '/']);
session_start();
if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Admin') === 0) {
    header('Location: ../../Index/ADMIN/Admin.php');
    exit;
}

if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Requester') === 0) {
    header('Location: ../../Index/REQUESTOR/REQ.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Approver') !== 0) {
    header('Location: ../../Login/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOLE Inventory System</title>
    <link rel="stylesheet" href="Central.css">
</head>
<body>

<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="../../Images/LOGO%20IN.png" alt="DOLE Logo">
            <div>
                <h3>Department of Labor</h3>
                <p>and Employment</p>
            </div>
        </div>
        <div class="profile">
            <div class="avatar"></div>
            <div>
                <h4><?php echo htmlspecialchars($_SESSION['username']); ?></h4>
                <p><?php echo htmlspecialchars($_SESSION['role']); ?></p>
            </div>
        </div>
        <p class="nav-label">NAVIGATION</p>
        <ul class="nav">
            <li class="active" data-page="dashboard"><span class="nav-icon"></span> Dashboard</li>
            <li data-page="inventory"><span class="nav-icon"></span> Inventory</li>
            <li data-page="notifications"><span class="nav-icon"></span> Notifications</li>
            <li data-page="approvals"><span class="nav-icon"></span> Request Approvals</li>
            <li data-page="delivery"><span class="nav-icon"></span> Delivery Status</li>
            <li data-page="logout"><span class="nav-icon"></span> Log out</li>
        </ul>
    </aside>

    <main class="main">
        <header class="topbar">
            <div>
                <h2 id="page-title">Dashboard</h2>
                <p class="subtitle">Explore your needs here</p>
            </div>
            <div class="time">
                <p>Philippine Standard Time:</p>
                <span id="clock"></span>
            </div>
        </header>

        <section id="dashboard" class="page active">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder blue">🔄</span> Requests Today</div>
                    <h1 id="requestsCount">07</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="approvals" data-filter="today">↗</a>
                </div>
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder blue">🕒</span> Pending Approvals</div>
                    <h1 id="approvalsCount">15</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="approvals" data-filter="pending">↗</a>
                </div>
                <div class="stat-card">
                    <div class="stat-header"><span class="icon-placeholder blue">📍</span> Active Deliveries</div>
                    <h1 id="deliveriesCount">03</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="delivery">↗</a>
                </div>
            </div>

            <div class="dashboard-lower">
                <div class="dashboard-box">
                    <div class="box-title">
                        <span class="icon-placeholder yellow">⚠️</span> Low Stock
                        <p class="box-subtitle">Items needing restock</p>
                        <a href="#" class="card-link dashboard-arrow" data-page="inventory" data-filter="low">↗</a>
                    </div>
                    <ul id="lowStockList" class="dashboard-list"></ul>
                </div>
                <div class="dashboard-box">
                    <div class="box-title">
                        <span class="icon-placeholder red">📦</span> Out of Stock
                        <p class="box-subtitle">Immediate restock</p>
                        <a href="#" class="card-link dashboard-arrow" data-page="inventory" data-filter="out">↗</a>
                    </div>
                    <ul id="outStockList" class="dashboard-list"></ul>
                </div>
            </div>
        </section>

        <section id="inventory" class="page">
            <div class="inventory-header">
                <div class="inventory-title-section">
                    <h3 class="inventory-title">All Items <span id="totalItemCount">0</span></h3>
                </div>
                <div class="inventory-actions">
                    <div class="search-wrapper">
                        <span class="search-icon">🔍</span>
                        <input id="searchInput" placeholder="Search">
                    </div>
                    <button id="addItemBtn" class="blue-btn">+ Add Item</button>
                </div>
            </div>
            <div class="inventory-table-container">
                <table class="inventory-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>In Stock</th>
                            <th>Status</th>
                            <th>Last Modified</th>
                            <th>Manage Stock</th>
                        </tr>
                    </thead>
                    <tbody id="inventoryTable"></tbody>
                </table>
            </div>
        </section>

        <section id="approvals" class="page">
            <div class="approvals-top-actions">
                <div class="filter-tabs">
                    <div class="tab active" data-filter="all" data-color="blue"><span class="dot"></span>All <span class="count" id="cnt-all">26</span></div>
                    <div class="tab" data-filter="today" data-color="yellow"><span class="dot"></span>Today <span class="count" id="cnt-today">07</span></div>
                    <div class="tab" data-filter="pending" data-color="orange"><span class="dot"></span>Pending <span class="count" id="cnt-pending">15</span></div>
                    <div class="tab" data-filter="approved" data-color="green"><span class="dot"></span>Approved <span class="count" id="cnt-approved">03</span></div>
                    <div class="tab" data-filter="declined" data-color="red"><span class="dot"></span>Declined <span class="count" id="cnt-declined">02</span></div>
                </div>
                <div class="action-buttons">
                    <button class="circle-btn">📖</button>
                    <button class="circle-btn">⇅</button>
                </div>
            </div>
            <div class="approvals-grid" id="approvalsGrid"></div>
        </section>

        <section id="notifications" class="page"></section>
        <section id="delivery" class="page"></section>
    </main>
</div>

<div class="modal-overlay" id="addItemsModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeModal">←</button>
            <h3>Add Items</h3>
        </div>
        <div class="modal-body">
            <div class="drop-zone" id="dropZone">
                <div class="drop-content">
                    <span class="upload-icon">☁️</span>
                    <p>Upload Image</p>
                </div>
                <input type="file" id="fileInput" hidden>
            </div>
            
            <div class="form-group">
                <label>ITEM ID</label>
                <input type="text" id="itemID" value="ITM0014" readonly class="readonly-input">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Item <span class="req">*</span></label>
                    <input type="text" placeholder="Item" id="newItemName">
                </div>
                <div class="form-group">
                    <label>Category <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newItemCategory">
                            <option value="">Category</option>
                            <option value="Paper Products">Paper Products</option>
                            <option value="Writing Supplies">Writing Supplies</option>
                            <option value="Office Supplies">Office Supplies</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>In Stock</label>
                    <input type="text" placeholder="In Stock" id="newItemStock">
                </div>
                <div class="form-group">
                    <label>Minimum Stock <span class="req">*</span></label>
                    <div class="number-input">
                        <input type="number" value="0" id="newItemMin">
                        <div class="spin-arrows">
                            <span class="up">▲</span>
                            <span class="down">▼</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelBtn">Cancel</button>
            <button class="btn-save" id="saveBtn">Save</button>
        </div>
    </div>
</div>

<div id="toastMessage" class="toast-message"></div>

<script>
    window.currentUserRole = <?php echo json_encode($_SESSION['role'] ?? ''); ?>;
    window.flashMessage = <?php echo json_encode($_SESSION['flash_message'] ?? ''); ?>;
    <?php if (!empty($_SESSION['flash_message'])) unset($_SESSION['flash_message']); ?>
</script>
<script src="Central.js"></script>
</body>
</html>
