<?php
session_set_cookie_params(['path' => '/']);
session_start();
require_once __DIR__ . '/../Login/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

function json_out(int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    json_out(401, ['success' => false, 'message' => 'Unauthorized']);
}

$role = (string)($_SESSION['role'] ?? '');
$isApprover = strcasecmp($role, 'Approver') === 0;

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET' && $action === 'list') {
    $stmt = $pdo->query("SELECT id, item_name, category, stock, unit, min_stock, DATE_FORMAT(last_modified, '%Y-%m-%d') AS last_modified FROM inventory_items ORDER BY item_name ASC");
    $items = $stmt->fetchAll();
    json_out(200, ['success' => true, 'data' => $items]);
}

// All mutations are Approver-only
if (!$isApprover) {
    json_out(403, ['success' => false, 'message' => 'Forbidden']);
}

$raw = file_get_contents('php://input');
$body = [];
if (is_string($raw) && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}

// allow form-encoded too
$body = array_merge($body, $_POST);

try {
    if ($action === 'add') {
        $name = trim((string)($body['item_name'] ?? ''));
        $category = trim((string)($body['category'] ?? ''));
        $stock = (int)($body['stock'] ?? 0);
        $unit = trim((string)($body['unit'] ?? 'pcs'));
        $min = (int)($body['min_stock'] ?? 0);

        if ($name === '' || $category === '') {
            json_out(422, ['success' => false, 'message' => 'Item name and category are required.']);
        }
        if ($unit === '') {
            json_out(422, ['success' => false, 'message' => 'Unit is required.']);
        }
        if ($stock < 0 || $min < 0) {
            json_out(422, ['success' => false, 'message' => 'Stock values must be non-negative.']);
        }

        $stmt = $pdo->prepare("INSERT INTO inventory_items (item_name, category, stock, unit, min_stock) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $category, $stock, $unit, $min]);
        json_out(200, ['success' => true]);
    }

    if ($action === 'update') {
        $id = (int)($body['id'] ?? 0);
        $name = trim((string)($body['item_name'] ?? ''));
        $category = trim((string)($body['category'] ?? ''));
        $unit = trim((string)($body['unit'] ?? 'pcs'));
        $min = (int)($body['min_stock'] ?? 0);

        if ($id <= 0 || $name === '' || $category === '') {
            json_out(422, ['success' => false, 'message' => 'Invalid item update payload.']);
        }
        if ($unit === '') {
            json_out(422, ['success' => false, 'message' => 'Unit is required.']);
        }
        if ($min < 0) {
            json_out(422, ['success' => false, 'message' => 'Minimum stock must be non-negative.']);
        }

        $stmt = $pdo->prepare("UPDATE inventory_items SET item_name = ?, category = ?, unit = ?, min_stock = ? WHERE id = ?");
        $stmt->execute([$name, $category, $unit, $min, $id]);
        json_out(200, ['success' => true]);
    }

    if ($action === 'updateStock') {
        $id = (int)($body['id'] ?? 0);
        $stock = (int)($body['stock'] ?? -1);
        if ($id <= 0 || $stock < 0) {
            json_out(422, ['success' => false, 'message' => 'Invalid stock update payload.']);
        }

        $stmt = $pdo->prepare("UPDATE inventory_items SET stock = ? WHERE id = ?");
        $stmt->execute([$stock, $id]);
        json_out(200, ['success' => true]);
    }

    if ($action === 'delete') {
        $id = (int)($body['id'] ?? 0);
        if ($id <= 0) {
            json_out(422, ['success' => false, 'message' => 'Invalid delete payload.']);
        }
        $stmt = $pdo->prepare("DELETE FROM inventory_items WHERE id = ?");
        $stmt->execute([$id]);
        json_out(200, ['success' => true]);
    }

    json_out(400, ['success' => false, 'message' => 'Unknown action.']);
} catch (PDOException $e) {
    json_out(500, ['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

