const showPass = document.querySelector(".show-pass");
const password = document.querySelector("input[type='password']");

showPass.addEventListener("click", () => {

if(password.type === "password"){
password.type = "text";
}
else{
password.type = "password";
}

});