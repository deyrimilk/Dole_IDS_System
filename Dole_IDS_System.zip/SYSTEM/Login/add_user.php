<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['path' => '/']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$password = $input['password'] ?? '';
$email = trim($input['email'] ?? '');
$fullname = trim($input['fullname'] ?? '');
$role = trim($input['role'] ?? '');
$province = trim($input['province'] ?? '');

if (!$username || !$password || !$email || !$fullname || !$role || !$province) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || stripos($email, '@gmail.com', -10) === false) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid Gmail address']);
    exit;
}

$validRoles = ['Admin', 'Approver', 'Requester', 'Delivery'];
if (!in_array($role, $validRoles, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid role']);
    exit;
}

require_once 'db_connect.php';

try {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$username, $passwordHash, $fullname, $email, $role, $province]);
    $userId = $pdo->lastInsertId();

    $stmt = $pdo->prepare('SELECT id, username, full_name, email, role, province, last_login, created_at FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    echo json_encode(['success' => true, 'data' => $user]);
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Username already exists']);
        exit;
    }

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to add user']);
}
