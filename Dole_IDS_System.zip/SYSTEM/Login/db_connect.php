<?php
// db_connect.php
// Use this file to connect to the login database from your PHP login scripts.

$host = '127.0.0.1';
$db   = 'dole_ids_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

function jsonErrorExit(string $message, int $statusCode = 500): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    http_response_code($statusCode);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    if ((string)$e->getCode() === '1049') {
        // Database does not exist yet. Create it, then create the users table.
        try {
            $pdo = new PDO("mysql:host=$host;charset=$charset", $user, $pass, $options);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db`");
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS `users` ("
                . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
                . "`username` VARCHAR(50) NOT NULL UNIQUE,"
                . "`password_hash` VARCHAR(255) NOT NULL,"
                . "`full_name` VARCHAR(100) NOT NULL,"
                . "`email` VARCHAR(100) DEFAULT NULL,"
                . "`role` ENUM('Admin','Approver','Requester') NOT NULL DEFAULT 'Requester',"
                . "`province` VARCHAR(100) DEFAULT NULL,"
                . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                . "`last_login` DATETIME DEFAULT NULL,"
                . "PRIMARY KEY (`id`)"
                . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );

            $adminHash = password_hash('AdminFMD03', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT IGNORE INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute(['AdminFMD03', $adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA']);
        } catch (PDOException $inner) {
            jsonErrorExit('Database initialization failed: ' . $inner->getMessage(), 500);
        }
    } else {
        jsonErrorExit('Database connection failed: ' . $e->getMessage(), 500);
    }
}

// Ensure the users table exists (DB may exist without the table).
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `users` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`username` VARCHAR(50) NOT NULL UNIQUE,"
        . "`password_hash` VARCHAR(255) NOT NULL,"
        . "`full_name` VARCHAR(100) NOT NULL,"
        . "`email` VARCHAR(100) DEFAULT NULL,"
        . "`role` ENUM('Admin','Approver','Requester') NOT NULL DEFAULT 'Requester',"
        . "`province` VARCHAR(100) DEFAULT NULL,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`last_login` DATETIME DEFAULT NULL,"
        . "PRIMARY KEY (`id`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    // Seed a default admin only if it does not exist yet.
    $adminHash = password_hash('AdminFMD03', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT IGNORE INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute(['AdminFMD03', $adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA']);
} catch (PDOException $e) {
    jsonErrorExit('Database initialization failed: ' . $e->getMessage(), 500);
}

// Normalize users table schema only when needed.
// Avoid running expensive ALTER statements on every request.
try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM `users`");
    $columns = [];
    while ($row = $columnStmt->fetch()) {
        $columns[$row['Field']] = $row;
    }

    if (!isset($columns['full_name'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `full_name` VARCHAR(100) NOT NULL DEFAULT '' AFTER `password_hash`");
    }
    if (!isset($columns['province'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `province` VARCHAR(100) DEFAULT NULL AFTER `role`");
    }
    if (!isset($columns['created_at'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `province`");
    }
    if (!isset($columns['last_login'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `last_login` DATETIME DEFAULT NULL AFTER `created_at`");
    }

    // Only change enum if table still uses the legacy role set.
    if (isset($columns['role']) && strpos(strtolower((string)$columns['role']['Type']), 'user') !== false) {
        $pdo->exec("ALTER TABLE `users` CHANGE COLUMN `role` `role` ENUM('Admin','Approver','Requester') NOT NULL DEFAULT 'Requester'");
        $pdo->exec("UPDATE `users` SET `role` = 'Requester' WHERE `role` = 'user'");
    }

    $pdo->exec("UPDATE `users` SET `full_name` = 'Admin FMD' WHERE `username` = 'AdminFMD03' AND (`full_name` IS NULL OR `full_name` = '')");
} catch (PDOException $e) {
    jsonErrorExit('Database schema repair failed: ' . $e->getMessage(), 500);
}

// --- INVENTORY TABLE (shared across portals) ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `inventory_items` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`category` VARCHAR(120) NOT NULL,"
        . "`stock` INT NOT NULL DEFAULT 0,"
        . "`unit` VARCHAR(50) NOT NULL DEFAULT 'pcs',"
        . "`min_stock` INT NOT NULL DEFAULT 0,"
        . "`last_modified` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`category`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $countStmt = $pdo->query("SELECT COUNT(*) AS c FROM `inventory_items`");
    $row = $countStmt->fetch();
    $count = (int)($row['c'] ?? 0);

    if ($count === 0) {
        $seed = [
            ['Black Ink Cartridges', 'Printer Supplies', 3, 'box', 10],
            ['Laser Toner', 'Printer Supplies', 5, 'cartridge', 8],
            ['Photo Paper', 'Printer Supplies', 12, 'pack', 20],
            ['Ballpoint Pens', 'Writing Supplies', 10, 'dozen', 40],
            ['Whiteboard Markers', 'Writing Supplies', 4, 'box', 30],
            ['Blue Ink Pens', 'Writing Supplies', 0, 'pack', 20],
            ['Gel Pens', 'Writing Supplies', 25, 'dozen', 30],
            ['Correction Fluid', 'Writing Supplies', 8, 'bottle', 15],
            ['Highlighters', 'Writing Supplies', 0, 'pack', 10],
            ['A4 Notebooks', 'Office Supplies', 5, 'dozen', 25],
            ['Paper Clips', 'Office Supplies', 50, 'box', 150],
            ['Staplers', 'Office Supplies', 0, 'pcs', 5],
            ['Binder Clips', 'Office Supplies', 18, 'box', 40],
            ['Desk Organizer', 'Office Supplies', 7, 'pcs', 10],
            ['Printer Paper', 'Paper Products', 0, 'ream', 20],
            ['Sticky Notes', 'Paper Products', 0, 'pack', 10],
            ['Manila Folders', 'Paper Products', 30, 'pack', 60],
            ['Notepads', 'Paper Products', 20, 'pad', 35],
        ];

        $ins = $pdo->prepare("INSERT INTO `inventory_items` (item_name, category, stock, unit, min_stock) VALUES (?, ?, ?, ?, ?)");
        foreach ($seed as $s) {
            $ins->execute($s);
        }
    }
} catch (PDOException $e) {
    jsonErrorExit('Inventory initialization failed: ' . $e->getMessage(), 500);
}

// Normalize inventory_items table schema to add unit column if missing.
try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM `inventory_items`");
    $columns = [];
    while ($row = $columnStmt->fetch()) {
        $columns[$row['Field']] = $row;
    }

    if (!isset($columns['unit'])) {
        $pdo->exec("ALTER TABLE `inventory_items` ADD COLUMN `unit` VARCHAR(50) NOT NULL DEFAULT 'pcs' AFTER `stock`");
        // Set appropriate units based on existing item names
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'box' WHERE `item_name` LIKE '%Cartridge%' OR `item_name` LIKE '%Ink%'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'cartridge' WHERE `item_name` = 'Laser Toner'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pack' WHERE `item_name` IN ('Photo Paper', 'Blue Ink Pens', 'Gel Pens', 'Highlighters', 'Sticky Notes', 'Manila Folders')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'dozen' WHERE `item_name` IN ('Ballpoint Pens', 'A4 Notebooks', 'Gel Pens')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'box' WHERE `item_name` IN ('Whiteboard Markers', 'Paper Clips', 'Binder Clips')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'bottle' WHERE `item_name` = 'Correction Fluid'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'ream' WHERE `item_name` = 'Printer Paper'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pad' WHERE `item_name` = 'Notepads'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pcs' WHERE `unit` = 'pcs' OR `unit` IS NULL");
    }
} catch (PDOException $e) {
    jsonErrorExit('Inventory schema repair failed: ' . $e->getMessage(), 500);
}

// --- REQUESTS TABLE ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `requests` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`quantity` INT NOT NULL,"
        . "`requestor` VARCHAR(100) NOT NULL,"
        . "`approver` VARCHAR(100) DEFAULT NULL,"
        . "`stock_status` ENUM('In Stock','Low Stock','Out of Stock') NOT NULL DEFAULT 'In Stock',"
        . "`status` ENUM('Pending','Approved','Declined') NOT NULL DEFAULT 'Pending',"
        . "`request_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`approved_date` DATETIME DEFAULT NULL,"
        . "`remarks` VARCHAR(255) DEFAULT NULL,"
        . "`note` TEXT DEFAULT NULL,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`status`),"
        . "INDEX (`request_date`),"
        . "INDEX (`requestor`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    // Seed sample requests if table is empty
    $countStmt = $pdo->query("SELECT COUNT(*) AS c FROM `requests`");
    $row = $countStmt->fetch();
    $count = (int)($row['c'] ?? 0);

    if ($count === 0) {
        $sampleRequests = [
            ['Sticky Notes', 12, 'Cavite', 'ApproverDonna', 'In Stock', 'Approved', '2026-02-10', '2026-02-10', 'In Stock', 'Ubos na lh.'],
            ['Ballpoint Pen (Black)', 8, 'Batangas', 'ApproverKurt', 'Low Stock', 'Pending', '2026-02-15', NULL, 'Low Stock', 'Need restock'],
            ['A4 Notebook', 45, 'Batangas', 'ApproverGab', 'In Stock', 'Approved', '2026-01-28', '2026-01-28', 'In Stock', 'Ubos na lh.'],
            ['Calculator', 5, 'Cavite', 'ApproverDonna', 'Low Stock', 'Pending', '2026-02-18', NULL, 'Low Stock', ''],
            ['Binder Clips', 5, 'Rizal', 'ApproverKurt', 'In Stock', 'Approved', '2026-01-20', '2026-01-20', 'In Stock', ''],
            ['Highlighter', 0, 'Rizal', 'ApproverGab', 'Out of Stock', 'Declined', '2026-01-30', '2026-01-30', 'Out of Stock', 'Declined by Kurt'],
            ['Ballpoint Pen (Black)', 30, 'Quezon', 'ApproverDonna', 'In Stock', 'Approved', '2026-02-05', '2026-02-05', 'In Stock', ''],
            ['Stapler', 0, 'Quezon', 'ApproverKurt', 'Out of Stock', 'Declined', '2026-01-25', '2026-01-25', 'Out of Stock', 'Declined by Kurt'],
            ['Folder (Expandable)', 6, 'Batangas', 'ApproverGab', 'Low Stock', 'Pending', '2026-02-12', NULL, 'Low Stock', ''],
            ['Bond Paper (Short)', 5, 'Cavite', 'ApproverDonna', 'Low Stock', 'Pending', '2026-02-10', NULL, 'Low Stock', 'Ubos na lh.'],
            ['Envelope (Long)', 30, 'Laguna', 'ApproverKurt', 'In Stock', 'Approved', '2026-02-08', '2026-02-08', 'In Stock', ''],
            ['Correction Tape', 4, 'Batangas', 'ApproverGab', 'Low Stock', 'Pending', '2026-02-11', NULL, 'Low Stock', ''],
            ['Printer Paper', 20, 'Cavite', 'ApproverDonna', 'Out of Stock', 'Approved', '2026-02-20', '2026-02-20', 'Out of Stock', '']
        ];

        $insReq = $pdo->prepare("INSERT INTO `requests` (item_name, quantity, requestor, approver, stock_status, status, request_date, approved_date, remarks, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($sampleRequests as $req) {
            $insReq->execute($req);
        }
    }
} catch (PDOException $e) {
    jsonErrorExit('Requests table initialization failed: ' . $e->getMessage(), 500);
}
