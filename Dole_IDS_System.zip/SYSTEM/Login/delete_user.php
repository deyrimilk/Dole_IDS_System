<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['path' => '/']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');

if (!$username) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username is required']);
    exit;
}

if ($username === $_SESSION['username']) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'You cannot delete the currently logged-in account']);
    exit;
}

require_once 'db_connect.php';

try {
    $stmt = $pdo->prepare('DELETE FROM users WHERE username = ?');
    $stmt->execute([$username]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not delete user']);
}
