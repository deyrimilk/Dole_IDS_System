<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['path' => '/']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once 'db_connect.php';

try {
    $stmt = $pdo->query('SELECT id, username, full_name, email, role, province, last_login, created_at FROM users ORDER BY created_at DESC');
    $users = $stmt->fetchAll();

    echo json_encode(['success' => true, 'data' => $users]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to fetch users: ' . $e->getMessage()]);
}
