<?php
session_set_cookie_params(['path' => '/']);
session_start();
require_once 'db_connect.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare('SELECT id, username, password_hash, role, full_name FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $updateStmt = $pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?');
            $updateStmt->execute([$user['id']]);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            $_SESSION['flash_message'] = 'Welcome, ' . $user['full_name'];

            if (strcasecmp($user['role'], 'Admin') === 0) {
                header('Location: ../Index/ADMIN/Admin.php');
            } elseif (strcasecmp($user['role'], 'Approver') === 0) {
                header('Location: ../Index/SUPPLY/Central.php');
            } elseif (strcasecmp($user['role'], 'Requester') === 0) {
                header('Location: ../Index/REQUESTOR/REQ.php');
            } else {
                header('Location: login.php');
            }
            exit;
        }

        $error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" href="Login.css">
</head>

<body>

<div class="background"></div>
<div class="bg-logo">
    <img src="../Images/LOGO%20BG.png" alt="Background Logo">
</div>

<div class="login-shell">
    <div class="login-card">
        <div class="brand-panel">
            <img class="brand-logo" src="../Images/LOGO%20OUT.png" alt="DOLE Logo">
        </div>

        <div class="form-panel">
            <h2>Welcome back!</h2>
            <p class="form-subtitle">Please enter your details.</p>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="post" action="login.php">
                <label class="field-label" for="username">Username</label>
                <div class="input-group">
                    <input id="username" type="text" name="username" placeholder="Username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" required>
                </div>

                <label class="field-label" for="password">Password</label>
                <div class="input-group">
                    <input id="password" type="password" name="password" placeholder="Password" required>
                    <span class="show-pass" title="Show/Hide password">👁</span>
                </div>

                <div class="options">
                    <label>
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="#">Forgot Password?</a>
                </div>

                <button type="submit" class="login-btn">LOGIN</button>
            </form>

            <p class="panel-footer">© 2026 DOLE.</p>
        </div>
    </div>
</div>

<script src="Login.js"></script>

</body>
</html>
