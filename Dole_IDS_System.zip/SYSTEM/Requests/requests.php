<?php
session_set_cookie_params(['path' => '/']);
session_start();

// Ensure user is logged in
if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../Login/db_connect.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? '';

try {
    if ($method === 'GET' && $action === 'list') {
        // Fetch all requests
        $stmt = $pdo->query("SELECT * FROM requests ORDER BY request_date DESC");
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $requests
        ]);
    } 
    elseif ($method === 'GET' && $action === 'recent') {
        // Fetch recent requests (for dashboard)
        $stmt = $pdo->query("SELECT * FROM requests ORDER BY request_date DESC LIMIT 5");
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $requests
        ]);
    }
    elseif ($method === 'GET' && $action === 'stats') {
        // Fetch request statistics
        $stats = [];
        
        // Total requests
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM requests");
        $stats['total'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Pending
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM requests WHERE status = 'Pending'");
        $stats['pending'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Approved
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM requests WHERE status = 'Approved'");
        $stats['approved'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Declined
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM requests WHERE status = 'Declined'");
        $stats['declined'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo json_encode([
            'success' => true,
            'data' => $stats
        ]);
    }
    elseif ($method === 'POST' && $action === 'update_status') {
        // Update request status
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['id']) || !isset($input['status'])) {
            throw new Exception('Missing required fields: id, status');
        }
        
        $allowedStatuses = ['Pending', 'Approved', 'Declined'];
        if (!in_array($input['status'], $allowedStatuses)) {
            throw new Exception('Invalid status');
        }
        
        $stmt = $pdo->prepare("UPDATE requests SET status = ?, approver = ?, approved_date = NOW() WHERE id = ?");
        $stmt->execute([
            $input['status'],
            $_SESSION['username'],
            $input['id']
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Request status updated successfully'
        ]);
    }
    else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action or method']);
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
